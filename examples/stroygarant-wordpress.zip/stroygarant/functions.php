<?php
if (!defined('ABSPATH')) { exit; }

define('SG_CONSENT_VERSION', '2026-09-07-v1');
define('SG_CONSENT_RETENTION_DAYS', 180);

function sg_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form','gallery','caption','style','script'));
    add_theme_support('custom-logo', array('height'=>120,'width'=>320,'flex-height'=>true,'flex-width'=>true));
}
add_action('after_setup_theme', 'sg_setup');

function sg_assets() {
    $v = wp_get_theme()->get('Version');
    wp_enqueue_style('sg-main', get_theme_file_uri('/assets/css/main.css'), array(), $v);
    wp_enqueue_script('sg-main', get_theme_file_uri('/assets/js/main.js'), array(), $v, true);
}
add_action('wp_enqueue_scripts', 'sg_assets');

function sg_create_front_page() {
    $front = (int) get_option('page_on_front');
    if (!$front) {
        $page = get_page_by_path('glavnaya');
        $front = $page ? (int) $page->ID : wp_insert_post(array(
            'post_title' => 'Главная', 'post_name' => 'glavnaya', 'post_status' => 'publish', 'post_type' => 'page'
        ));
        if ($front && !is_wp_error($front)) {
            update_option('show_on_front', 'page');
            update_option('page_on_front', $front);
        }
    }

}
add_action('after_switch_theme', 'sg_create_front_page');

/**
 * Create dedicated legal pages owned by this theme. We intentionally use
 * unique slugs so a standard WordPress "Privacy Policy" page cannot hijack
 * the links from the form/footer.
 */
function sg_ensure_legal_pages() {
    $version = wp_get_theme()->get('Version');
    $stamp = get_option('sg_legal_pages_version');
    $privacy_id = (int) get_option('sg_privacy_page_id');
    $consent_id = (int) get_option('sg_consent_page_id');

    if ($stamp === $version && $privacy_id && get_post_status($privacy_id) && $consent_id && get_post_status($consent_id)) {
        return;
    }

    $pages = array(
        'privacy' => array(
            'option' => 'sg_privacy_page_id',
            'slug' => 'politika-obrabotki-personalnyh-dannyh',
            'title' => 'Политика обработки персональных данных',
            'content' => '[sg_privacy_policy]',
        ),
        'consent' => array(
            'option' => 'sg_consent_page_id',
            'slug' => 'soglasie-na-obrabotku-personalnyh-dannyh',
            'title' => 'Согласие на обработку персональных данных',
            'content' => '[sg_personal_data_consent]',
        ),
    );

    foreach ($pages as $page) {
        $id = (int) get_option($page['option']);
        $post = $id ? get_post($id) : null;
        if (!$post || $post->post_type !== 'page') {
            $existing = get_page_by_path($page['slug']);
            $id = $existing ? (int) $existing->ID : 0;
        }

        $data = array(
            'post_title' => $page['title'],
            'post_name' => $page['slug'],
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_content' => $page['content'],
        );

        if ($id) {
            $data['ID'] = $id;
            wp_update_post($data);
        } else {
            $id = wp_insert_post($data);
        }

        if ($id && !is_wp_error($id)) {
            update_option($page['option'], (int) $id);
            update_post_meta($id, '_sg_legal_page', '1');
        }
    }

    update_option('sg_legal_pages_version', $version);
}
add_action('init', 'sg_ensure_legal_pages', 20);

function sg_privacy_url() {
    $id = (int) get_option('sg_privacy_page_id');
    return $id && get_post_status($id) ? get_permalink($id) : home_url('/politika-obrabotki-personalnyh-dannyh/');
}
function sg_consent_url() {
    $id = (int) get_option('sg_consent_page_id');
    return $id && get_post_status($id) ? get_permalink($id) : home_url('/soglasie-na-obrabotku-personalnyh-dannyh/');
}

function sg_admin_notice_acf() {
    if (!current_user_can('activate_plugins') || function_exists('acf_add_local_field_group')) return;
    echo '<div class="notice notice-warning"><p><strong>Строй Гарант ACF:</strong> установите и активируйте <strong>ACF Pro</strong>. Для редактирования услуг и галерей используются Repeater и Gallery.</p></div>';
}
add_action('admin_notices', 'sg_admin_notice_acf');

function sg_register_acf_fields() {
    if (!function_exists('acf_add_local_field_group')) return;
    acf_add_local_field_group(array(
        'key'=>'group_sg_landing','title'=>'Строй Гарант — контент главной','position'=>'normal','style'=>'default','menu_order'=>0,
        'location'=>array(array(array('param'=>'page_type','operator'=>'==','value'=>'front_page'))),
        'fields'=>array(
            array('key'=>'field_sg_tab_hero','label'=>'Первый экран','type'=>'tab'),
            array('key'=>'field_sg_company','label'=>'Название компании','name'=>'company_name','type'=>'text','default_value'=>'Строй Гарант'),
            array('key'=>'field_sg_logo','label'=>'Логотип','name'=>'company_logo','type'=>'image','return_format'=>'id','preview_size'=>'medium'),
            array('key'=>'field_sg_hero_title','label'=>'Главный заголовок','name'=>'hero_title','type'=>'text','default_value'=>'Ремонт и отделка коммерческих и жилых помещений под ключ в Москве'),
            array('key'=>'field_sg_hero_text','label'=>'Подзаголовок','name'=>'hero_text','type'=>'textarea','rows'=>3,'default_value'=>'Берём объект от черновых работ и инженерии до финишной отделки и сдачи. Один подрядчик на весь цикл работ.'),
            array('key'=>'field_sg_hero_image','label'=>'Фоновое фото','name'=>'hero_image','type'=>'image','return_format'=>'id','preview_size'=>'medium'),
            array('key'=>'field_sg_cta','label'=>'Текст кнопки','name'=>'cta_text','type'=>'text','default_value'=>'Рассчитать стоимость'),

            array('key'=>'field_sg_tab_about','label'=>'О компании','type'=>'tab'),
            array('key'=>'field_sg_about_title','label'=>'Заголовок','name'=>'about_title','type'=>'text','default_value'=>'Один подрядчик — полный цикл работ'),
            array('key'=>'field_sg_about_text','label'=>'Текст','name'=>'about_text','type'=>'wysiwyg','tabs'=>'visual','toolbar'=>'basic','media_upload'=>0),

            array('key'=>'field_sg_tab_services','label'=>'Услуги','type'=>'tab'),
            array('key'=>'field_sg_services_title','label'=>'Заголовок секции','name'=>'services_title','type'=>'text','default_value'=>'Всё необходимое для реализации объекта'),
            array('key'=>'field_sg_services','label'=>'Услуги','name'=>'services','type'=>'repeater','layout'=>'block','button_label'=>'Добавить услугу','collapsed'=>'field_sg_service_title','sub_fields'=>array(
                array('key'=>'field_sg_service_title','label'=>'Название','name'=>'title','type'=>'text','required'=>1),
                array('key'=>'field_sg_service_text','label'=>'Описание','name'=>'text','type'=>'textarea','rows'=>3),
                array('key'=>'field_sg_service_image','label'=>'Фото','name'=>'image','type'=>'image','return_format'=>'id','preview_size'=>'medium'),
            )),

            array('key'=>'field_sg_tab_projects','label'=>'Наши работы','type'=>'tab'),
            array('key'=>'field_sg_projects_title','label'=>'Заголовок секции','name'=>'projects_title','type'=>'text','default_value'=>'Объекты, которые говорят за нас'),
            array('key'=>'field_sg_projects','label'=>'Проекты','name'=>'projects','type'=>'repeater','layout'=>'block','button_label'=>'Добавить проект','collapsed'=>'field_sg_project_title','sub_fields'=>array(
                array('key'=>'field_sg_project_title','label'=>'Название проекта','name'=>'title','type'=>'text','required'=>1),
                array('key'=>'field_sg_project_type','label'=>'Тип / услуга','name'=>'type','type'=>'text'),
                array('key'=>'field_sg_project_text','label'=>'Описание','name'=>'text','type'=>'textarea','rows'=>3),
                array('key'=>'field_sg_project_cover','label'=>'Обложка','name'=>'cover','type'=>'image','return_format'=>'id','preview_size'=>'medium'),
                array('key'=>'field_sg_project_gallery','label'=>'Галерея','name'=>'gallery','type'=>'gallery','return_format'=>'id','preview_size'=>'medium','library'=>'all'),
            )),

            array('key'=>'field_sg_tab_contacts','label'=>'Контакты и форма','type'=>'tab'),
            array('key'=>'field_sg_contacts_title','label'=>'Заголовок','name'=>'contacts_title','type'=>'text','default_value'=>'Обсудим ваш объект и следующий шаг'),
            array('key'=>'field_sg_phone','label'=>'Телефон','name'=>'phone','type'=>'text'),
            array('key'=>'field_sg_email','label'=>'Email','name'=>'email','type'=>'email','default_value'=>'demo@example.invalid'),
            array('key'=>'field_sg_address','label'=>'Адрес','name'=>'address','type'=>'textarea','rows'=>3,'default_value'=>''),
            array('key'=>'field_sg_form_email','label'=>'Email для заявок','name'=>'form_email','type'=>'email','default_value'=>'demo@example.invalid'),
            array('key'=>'field_sg_operator_name','label'=>'Юридическое наименование оператора ПД','name'=>'operator_name','type'=>'text','default_value'=>'Общество с ограниченной ответственностью «СТРОЙ ГАРАНТ»','instructions'=>'Укажите точное наименование ООО/ИП, которое является оператором персональных данных.'),
            array('key'=>'field_sg_operator_inn','label'=>'ИНН оператора','name'=>'operator_inn','type'=>'text','default_value'=>''),
            array('key'=>'field_sg_operator_ogrn','label'=>'ОГРН / ОГРНИП','name'=>'operator_ogrn','type'=>'text','default_value'=>''),
            array('key'=>'field_sg_operator_kpp','label'=>'КПП','name'=>'operator_kpp','type'=>'text','default_value'=>''),
            array('key'=>'field_sg_form_title','label'=>'Заголовок формы','name'=>'form_title','type'=>'text','default_value'=>'Получить предварительную оценку'),
            array('key'=>'field_sg_form_text','label'=>'Текст формы','name'=>'form_text','type'=>'textarea','rows'=>2,'default_value'=>'Оставьте контакты и коротко опишите объект. Свяжемся с вами, уточним задачу и предложим следующий шаг.'),
            array('key'=>'field_sg_form_button','label'=>'Кнопка формы','name'=>'form_button','type'=>'text','default_value'=>'Отправить заявку'),
        )
    ));
}
// ACF 6.2+ recommends registering exported/local fields on acf/include_fields.
// This avoids re-entering ACF initialization from a theme callback.
add_action('acf/include_fields','sg_register_acf_fields');

/**
 * Front-end reads intentionally bypass the ACF API.
 * ACF stores normal fields in wp_postmeta, so reading post meta directly keeps
 * the public site independent from ACF's runtime initialization and prevents
 * recursive acf_init() failures seen with some local ACF Pro installs.
 */
function sg_acf_ready() {
    return function_exists('acf_add_local_field_group');
}
function sg_get_field_safe($name, $post_id = false, $fallback = '') {
    $post_id = $post_id ? (int) $post_id : (int) get_queried_object_id();
    if (!$post_id) return $fallback;
    $value = get_post_meta($post_id, $name, true);
    return ($value !== null && $value !== '' && $value !== false) ? $value : $fallback;
}
function sg_get_repeater_rows($name, $post_id, $subfields) {
    $post_id = (int) $post_id;
    if (!$post_id) return array();
    $count = (int) get_post_meta($post_id, $name, true);
    if ($count < 1) return array();
    $rows = array();
    for ($i = 0; $i < $count; $i++) {
        $row = array();
        foreach ($subfields as $subfield) {
            $row[$subfield] = get_post_meta($post_id, $name . '_' . $i . '_' . $subfield, true);
        }
        $rows[] = $row;
    }
    return $rows;
}




/**
 * Seed the bundled demo content into real ACF-compatible post meta.
 * This runs once for a fresh front page and never overwrites projects/services
 * that were already saved by the client. Bundled project photos are copied to
 * the WordPress Media Library so ACF Image/Gallery fields can manage them.
 */
function sg_set_acf_meta($post_id, $name, $field_key, $value) {
    update_post_meta($post_id, $name, $value);
    update_post_meta($post_id, '_' . $name, $field_key);
}

function sg_import_bundled_image($relative) {
    $relative = ltrim((string) $relative, '/');
    if (!$relative) return 0;

    $existing = get_posts(array(
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'posts_per_page' => 1,
        'fields'         => 'ids',
        'meta_key'       => '_sg_bundled_asset',
        'meta_value'     => $relative,
    ));
    if ($existing) return (int) $existing[0];

    $source = get_theme_file_path('/assets/images/' . $relative);
    if (!is_file($source) || !is_readable($source)) return 0;

    $filename = basename($source);
    $bits = wp_upload_bits($filename, null, file_get_contents($source));
    if (!empty($bits['error'])) return 0;

    $filetype = wp_check_filetype($bits['file']);
    $attachment_id = wp_insert_attachment(array(
        'post_mime_type' => $filetype['type'] ?: 'image/jpeg',
        'post_title'     => sanitize_text_field(pathinfo($filename, PATHINFO_FILENAME)),
        'post_content'   => '',
        'post_status'    => 'inherit',
    ), $bits['file']);
    if (!$attachment_id || is_wp_error($attachment_id)) return 0;

    require_once ABSPATH . 'wp-admin/includes/image.php';
    $metadata = wp_generate_attachment_metadata($attachment_id, $bits['file']);
    if ($metadata) wp_update_attachment_metadata($attachment_id, $metadata);
    update_post_meta($attachment_id, '_sg_bundled_asset', $relative);
    return (int) $attachment_id;
}

function sg_seed_project_definitions() {
    return array(
        array('title'=>'Bar Body Studio — Белорусская','type'=>'Коммерческое помещение / массажный салон','text'=>'Ремонт и внутренняя отделка коммерческого помещения под ключ.','cover'=>'projects/bar-body-bel/13.42.15.jpg','gallery'=>array('13.42.15','13.42.36','13.42.58','13.43.03','13.43.09','13.43.16','13.43.22','13.43.47','13.43.55','13.44.01','13.44.07','13.44.13','13.44.17','13.44.21','13.44.25'),'folder'=>'bar-body-bel'),
        array('title'=>'Bar Body Studio — Олимпийский проспект','type'=>'Коммерческое помещение / массажный салон','text'=>'Комплексная внутренняя отделка помещения с готовыми кабинетами и санитарной зоной.','cover'=>'projects/bar-body-olymp/13.52.38.jpg','gallery'=>array('13.52.34','13.52.38','13.52.42','13.52.47','13.52.50'),'folder'=>'bar-body-olymp'),
        array('title'=>'Ремонт квартиры под ключ — проект 1','type'=>'Жилой сектор','text'=>'Комплексный ремонт квартиры с кухней, санузлом, инженерией и чистовой отделкой.','cover'=>'projects/apartment-1/13.56.20.jpg','gallery'=>array('13.56.20','13.56.26','13.56.29','13.56.36','13.56.41','13.56.45','13.56.55','13.57.00','13.57.06'),'folder'=>'apartment-1'),
        array('title'=>'Ремонт квартиры под ключ — проект 2','type'=>'Жилой сектор','text'=>'Полный цикл ремонта квартиры: отделка, освещение, санузел, кухня и встроенные решения.','cover'=>'projects/apartment-2/13.59.22.jpg','gallery'=>array('13.58.49','13.58.55','13.59.04','13.59.15','13.59.18','13.59.22','13.59.25','13.59.28','13.59.33','13.59.39','13.59.44','13.59.47','13.59.53','13.59.56','14.00.00'),'folder'=>'apartment-2'),
        array('title'=>'Ресторан Ketch Up — Покровка','type'=>'Коммерческое помещение / ресторан','text'=>'Комплексная реализация коммерческого интерьера с декоративной отделкой, освещением и посадочными зонами.','cover'=>'projects/ketchup/14.01.05.jpg','gallery'=>array('14.00.58','14.01.01','14.01.05','14.01.11','14.01.16','14.01.25','14.01.34','14.01.38'),'folder'=>'ketchup'),
        array('title'=>'Ремонт и внутренняя отделка помещений','type'=>'Коммерческое помещение','text'=>'Чистовая отделка помещения: плиточные полы, подвесной потолок, освещение, двери и финишная отделка стен.','cover'=>'projects/finishing/14.03.45.jpg','gallery'=>array('14.03.42','14.03.45','14.03.50','14.03.53'),'folder'=>'finishing'),
    );
}

function sg_seed_service_definitions() {
    return array(
        array('title'=>'Комплексное строительство','text'=>'Работаем как подрядчик полного цикла на объектах жилого и коммерческого сектора: от строительных этапов до сдачи готового объекта.','image'=>'projects/ketchup/14.01.05.jpg'),
        array('title'=>'Ремонт квартир под ключ','text'=>'Комплексный ремонт жилых помещений: инженерные работы, черновая и чистовая отделка, освещение, сантехника и финишная сборка.','image'=>'projects/apartment-2/13.59.22.jpg'),
        array('title'=>'Ремонт коммерческих помещений','text'=>'Реализация интерьеров для ресторанов, салонов, офисов и других коммерческих объектов с координацией всех этапов работ.','image'=>'projects/bar-body-bel/13.42.15.jpg'),
        array('title'=>'Ремонт и внутренняя отделка помещений','text'=>'Подготовка поверхностей, отделка стен и полов, монтаж потолков, дверей, освещения и других элементов чистовой отделки.','image'=>'projects/finishing/14.03.45.jpg'),
        array('title'=>'Монтаж инженерных коммуникаций','text'=>'Выполняем инженерные работы на объектах в рамках комплексной реализации проекта с соблюдением согласованного графика производства работ.','image'=>'projects/ketchup/14.01.16.jpg'),
    );
}

function sg_seed_existing_content_into_acf() {
    if (!is_admin() || !current_user_can('edit_pages')) return;
    if (get_option('sg_acf_seed_v9_done')) return;

    $front = (int) get_option('page_on_front');
    if (!$front || get_post_type($front) !== 'page') return;

    // Populate normal fields only when the user has not already saved a value.
    $about_default = '<p><strong>Строй Гарант</strong> — строительная компания полного цикла для коммерческих и жилых объектов в Москве. Берём на себя строительные, отделочные и инженерные работы и отвечаем за результат одной командой.</p><p>Работаем с застройщиками, девелоперами, инвесторами, бизнесом и частными заказчиками. Соблюдаем согласованный график производства работ и применимые требования СНиП, ПУЭ и ГОСТ.</p>';
    $scalar = array(
        'company_name'=>array('field_sg_company','Строй Гарант'),
        'hero_title'=>array('field_sg_hero_title','Ремонт и отделка коммерческих и жилых помещений под ключ в Москве'),
        'hero_text'=>array('field_sg_hero_text','Берём объект от черновых работ и инженерии до финишной отделки и сдачи. Один подрядчик на весь цикл работ.'),
        'cta_text'=>array('field_sg_cta','Рассчитать стоимость'),
        'about_title'=>array('field_sg_about_title','Один подрядчик — полный цикл работ'),
        'about_text'=>array('field_sg_about_text',$about_default),
        'services_title'=>array('field_sg_services_title','Всё необходимое для реализации объекта'),
        'projects_title'=>array('field_sg_projects_title','Объекты, которые говорят за нас'),
        'contacts_title'=>array('field_sg_contacts_title','Обсудим ваш объект и следующий шаг'),
        'email'=>array('field_sg_email','demo@example.invalid'),
        'address'=>array('field_sg_address',''),
        'form_email'=>array('field_sg_form_email','demo@example.invalid'),
        'operator_name'=>array('field_sg_operator_name','Общество с ограниченной ответственностью «СТРОЙ ГАРАНТ»'),
        'operator_inn'=>array('field_sg_operator_inn',''),
        'operator_ogrn'=>array('field_sg_operator_ogrn',''),
        'operator_kpp'=>array('field_sg_operator_kpp',''),
        'form_title'=>array('field_sg_form_title','Получить предварительную оценку'),
        'form_text'=>array('field_sg_form_text','Оставьте контакты и коротко опишите объект. Свяжемся с вами, уточним задачу и предложим следующий шаг.'),
        'form_button'=>array('field_sg_form_button','Отправить заявку'),
    );
    foreach ($scalar as $name => $spec) {
        if (get_post_meta($front, $name, true) === '') sg_set_acf_meta($front, $name, $spec[0], $spec[1]);
    }

    // Import projects only if the repeater is currently empty.
    if ((int) get_post_meta($front, 'projects', true) < 1) {
        $projects = sg_seed_project_definitions();
        sg_set_acf_meta($front, 'projects', 'field_sg_projects', count($projects));
        foreach ($projects as $i => $project) {
            sg_set_acf_meta($front, "projects_{$i}_title", 'field_sg_project_title', $project['title']);
            sg_set_acf_meta($front, "projects_{$i}_type", 'field_sg_project_type', $project['type']);
            sg_set_acf_meta($front, "projects_{$i}_text", 'field_sg_project_text', $project['text']);
            $cover_id = sg_import_bundled_image($project['cover']);
            sg_set_acf_meta($front, "projects_{$i}_cover", 'field_sg_project_cover', $cover_id);
            $gallery_ids = array();
            foreach ($project['gallery'] as $file) {
                $id = sg_import_bundled_image('projects/' . $project['folder'] . '/' . $file . '.jpg');
                if ($id) $gallery_ids[] = $id;
            }
            sg_set_acf_meta($front, "projects_{$i}_gallery", 'field_sg_project_gallery', $gallery_ids);
        }
    }

    // Import services only if the repeater is currently empty.
    if ((int) get_post_meta($front, 'services', true) < 1) {
        $services = sg_seed_service_definitions();
        sg_set_acf_meta($front, 'services', 'field_sg_services', count($services));
        foreach ($services as $i => $service) {
            sg_set_acf_meta($front, "services_{$i}_title", 'field_sg_service_title', $service['title']);
            sg_set_acf_meta($front, "services_{$i}_text", 'field_sg_service_text', $service['text']);
            $image_id = sg_import_bundled_image($service['image']);
            sg_set_acf_meta($front, "services_{$i}_image", 'field_sg_service_image', $image_id);
        }
    }

    // Make the hero image editable too, using an already imported project image.
    if (!(int) get_post_meta($front, 'hero_image', true)) {
        $hero_id = sg_import_bundled_image('projects/ketchup/14.01.05.jpg');
        if ($hero_id) sg_set_acf_meta($front, 'hero_image', 'field_sg_hero_image', $hero_id);
    }

    update_option('sg_acf_seed_v9_done', 1, false);
    set_transient('sg_acf_seed_notice', 1, 60);
}
add_action('admin_init', 'sg_seed_existing_content_into_acf', 30);

function sg_acf_seed_notice() {
    if (!current_user_can('edit_pages') || !get_transient('sg_acf_seed_notice')) return;
    delete_transient('sg_acf_seed_notice');
    echo '<div class="notice notice-success is-dismissible"><p><strong>Строй Гарант:</strong> текущие услуги и 6 проектов перенесены в редактируемые поля ACF. Фотографии добавлены в Медиатеку. Теперь их можно менять на странице «Главная».</p></div>';
}
add_action('admin_notices', 'sg_acf_seed_notice');

function sg_asset($path) { return get_theme_file_uri('/assets/images/' . ltrim($path,'/')); }
function sg_img_list($folder, $files) {
    $out = array(); foreach ($files as $file) $out[] = sg_asset('projects/'.$folder.'/'.$file.'.jpg'); return $out;
}
function sg_default_services() {
    return array(
        array('title'=>'Комплексное строительство','text'=>'Работаем как подрядчик полного цикла на объектах жилого и коммерческого сектора: от строительных этапов до сдачи готового объекта.','image'=>sg_asset('projects/ketchup/14.01.05.jpg')),
        array('title'=>'Ремонт квартир под ключ','text'=>'Комплексный ремонт жилых помещений: инженерные работы, черновая и чистовая отделка, освещение, сантехника и финишная сборка.','image'=>sg_asset('projects/apartment-2/13.59.22.jpg')),
        array('title'=>'Ремонт коммерческих помещений','text'=>'Реализация интерьеров для ресторанов, салонов, офисов и других коммерческих объектов с координацией всех этапов работ.','image'=>sg_asset('projects/bar-body-bel/13.42.15.jpg')),
        array('title'=>'Ремонт и внутренняя отделка помещений','text'=>'Подготовка поверхностей, отделка стен и полов, монтаж потолков, дверей, освещения и других элементов чистовой отделки.','image'=>sg_asset('projects/finishing/14.03.45.jpg')),
        array('title'=>'Монтаж инженерных коммуникаций','text'=>'Выполняем инженерные работы на объектах в рамках комплексной реализации проекта с соблюдением согласованного графика производства работ.','image'=>sg_asset('projects/ketchup/14.01.16.jpg')),
    );
}
function sg_default_projects() {
    return array(
        array('title'=>'Bar Body Studio — Белорусская','type'=>'Коммерческое помещение / массажный салон','text'=>'Ремонт и внутренняя отделка коммерческого помещения под ключ.','cover'=>sg_asset('projects/bar-body-bel/13.42.15.jpg'),'gallery'=>sg_img_list('bar-body-bel',array('13.42.15','13.42.36','13.42.58','13.43.03','13.43.09','13.43.16','13.43.22','13.43.47','13.43.55','13.44.01','13.44.07','13.44.13','13.44.17','13.44.21','13.44.25'))),
        array('title'=>'Bar Body Studio — Олимпийский проспект','type'=>'Коммерческое помещение / массажный салон','text'=>'Комплексная внутренняя отделка помещения с готовыми кабинетами и санитарной зоной.','cover'=>sg_asset('projects/bar-body-olymp/13.52.38.jpg'),'gallery'=>sg_img_list('bar-body-olymp',array('13.52.34','13.52.38','13.52.42','13.52.47','13.52.50'))),
        array('title'=>'Ремонт квартиры под ключ — проект 1','type'=>'Жилой сектор','text'=>'Комплексный ремонт квартиры с кухней, санузлом, инженерией и чистовой отделкой.','cover'=>sg_asset('projects/apartment-1/13.56.20.jpg'),'gallery'=>sg_img_list('apartment-1',array('13.56.20','13.56.26','13.56.29','13.56.36','13.56.41','13.56.45','13.56.55','13.57.00','13.57.06'))),
        array('title'=>'Ремонт квартиры под ключ — проект 2','type'=>'Жилой сектор','text'=>'Полный цикл ремонта квартиры: отделка, освещение, санузел, кухня и встроенные решения.','cover'=>sg_asset('projects/apartment-2/13.59.22.jpg'),'gallery'=>sg_img_list('apartment-2',array('13.58.49','13.58.55','13.59.04','13.59.15','13.59.18','13.59.22','13.59.25','13.59.28','13.59.33','13.59.39','13.59.44','13.59.47','13.59.53','13.59.56','14.00.00'))),
        array('title'=>'Ресторан Ketch Up — Покровка','type'=>'Коммерческое помещение / ресторан','text'=>'Комплексная реализация коммерческого интерьера с декоративной отделкой, освещением и посадочными зонами.','cover'=>sg_asset('projects/ketchup/14.01.05.jpg'),'gallery'=>sg_img_list('ketchup',array('14.00.58','14.01.01','14.01.05','14.01.11','14.01.16','14.01.25','14.01.34','14.01.38'))),
        array('title'=>'Ремонт и внутренняя отделка помещений','type'=>'Коммерческое помещение','text'=>'Чистовая отделка помещения: плиточные полы, подвесной потолок, освещение, двери и финишная отделка стен.','cover'=>sg_asset('projects/finishing/14.03.45.jpg'),'gallery'=>sg_img_list('finishing',array('14.03.42','14.03.45','14.03.50','14.03.53'))),
    );
}

function sg_phone_href($phone) { return preg_replace('/[^0-9+]/','',$phone); }
function sg_form_redirect($status) {
    $url = wp_get_referer() ?: home_url('/');
    wp_safe_redirect(add_query_arg('form_status',$status,$url).'#contacts'); exit;
}
function sg_submit_lead() {
    if (!isset($_POST['sg_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['sg_nonce'])),'sg_submit_lead')) sg_form_redirect('error');
    if (!empty($_POST['website'])) sg_form_redirect('success');
    $name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
    $phone = isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '';
    $message = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';
    $consent = !empty($_POST['privacy_consent']) && wp_unslash($_POST['privacy_consent']) === '1';
    if (!$name || !$phone || !$consent) sg_form_redirect('error');
    $front = (int) get_option('page_on_front');
    $to = sg_get_field_safe('form_email', $front, '');
    if (!$to || !is_email($to)) $to = 'demo@example.invalid';
    $subject = 'Новая заявка с сайта Строй Гарант';
    $consent_text = wp_strip_all_tags(do_shortcode(sg_consent_content()));
    $consent_hash = hash('sha256', SG_CONSENT_VERSION . "\n" . $consent_text);
    $body = "Имя: {$name}\nТелефон: {$phone}\n\nСообщение:\n{$message}"
        . "\n\n--- ПОДТВЕРЖДЕНИЕ СОГЛАСИЯ ---"
        . "\nСогласие: получено отдельной обязательной галочкой"
        . "\nВерсия согласия: ".SG_CONSENT_VERSION
        . "\nДата и время: ".wp_date('d.m.Y H:i:s T')
        . "\nСтраница формы: ".home_url('/#contacts')
        . "\nСтраница согласия: ".sg_consent_url()
        . "\nПолитика: ".sg_privacy_url()
        . "\nSHA-256 текста согласия: {$consent_hash}"
        . "\n\nТекст согласия на момент отправки:\n{$consent_text}";
    $sent = wp_mail($to,$subject,$body,array('Content-Type: text/plain; charset=UTF-8'));
    sg_form_redirect($sent ? 'success' : 'error');
}
add_action('admin_post_nopriv_sg_submit_lead','sg_submit_lead');
add_action('admin_post_sg_submit_lead','sg_submit_lead');


function sg_front_field($name, $fallback='') {
    $front = (int) get_option('page_on_front');
    if (!$front) return $fallback;
    return sg_get_field_safe($name, $front, $fallback);
}

function sg_legal_operator_name() { return sg_front_field('operator_name', 'Общество с ограниченной ответственностью «СТРОЙ ГАРАНТ»'); }
function sg_legal_address() { return sg_front_field('address', ''); }
function sg_legal_email() { return sg_front_field('email', 'demo@example.invalid'); }
function sg_legal_inn() { return sg_front_field('operator_inn', ''); }
function sg_legal_ogrn() { return sg_front_field('operator_ogrn', ''); }
function sg_legal_kpp() { return sg_front_field('operator_kpp', ''); }

function sg_privacy_policy_content() {
    return '<p><strong>Редакция:</strong> '.esc_html(SG_CONSENT_VERSION).'</p>
<p><strong>Оператор персональных данных:</strong> [sg_operator_name]. Адрес: [sg_operator_address]. Email для обращений по вопросам персональных данных: [sg_operator_email]. [sg_operator_requisites]</p>
<h2>1. Общие положения</h2>
<p>Настоящая Политика определяет порядок обработки и защиты персональных данных посетителей сайта [sg_site_host] (далее — Сайт). Оператор обрабатывает персональные данные в соответствии с Федеральным законом от 27.07.2006 № 152-ФЗ «О персональных данных» и иными применимыми требованиями законодательства Российской Федерации.</p>
<h2>2. Цели, категории субъектов и состав данных</h2>
<p><strong>Обработка обращений и обратная связь.</strong> Субъекты — посетители Сайта, направляющие заявку. Данные: имя, номер телефона, текст обращения и сведения, добровольно указанные пользователем в сообщении. Цель — принять обращение, связаться с пользователем, уточнить параметры объекта и предоставить запрошенную информацию об услугах.</p>
<p><strong>Обеспечение работы и безопасности Сайта.</strong> При обращении к Сайту сервер и инфраструктура хостинга могут автоматически фиксировать технические сведения, в частности IP-адрес, дату и время запроса, адрес запрошенной страницы, сведения о браузере и устройстве. Такие сведения используются для обеспечения работоспособности, информационной безопасности и диагностики ошибок.</p>
<h2>3. Правовые основания</h2>
<p>Для обработки данных, направленных через форму, правовым основанием является согласие субъекта персональных данных. В случаях, предусмотренных законодательством, обработка также может осуществляться для заключения или исполнения договора по инициативе субъекта либо для исполнения обязанностей, возложенных на оператора законом.</p>
<h2>4. Действия и способы обработки</h2>
<p>Оператор может осуществлять сбор, запись, систематизацию, накопление, хранение, уточнение (обновление, изменение), извлечение, использование, передачу лицам, обрабатывающим данные по поручению оператора в необходимом объёме, блокирование, удаление и уничтожение персональных данных. Обработка может осуществляться с использованием средств автоматизации и без их использования.</p>
<h2>5. Передача и обработчики</h2>
<p>Для функционирования Сайта данные могут обрабатываться организациями, предоставляющими оператору услуги хостинга, технической поддержки и электронной почты, исключительно в объёме, необходимом для оказания соответствующих услуг и при наличии надлежащего правового основания. Оператор не продаёт персональные данные и не использует данные заявки для рекламных рассылок без отдельного согласия.</p>
<h2>6. Локализация и трансграничная передача</h2>
<p>При сборе персональных данных граждан Российской Федерации через Интернет оператор обеспечивает выполнение требований законодательства о записи, систематизации, накоплении, хранении, уточнении и извлечении таких данных с использованием баз данных, находящихся на территории Российской Федерации. Трансграничная передача данных через функциональность настоящего Сайта оператором не предусматривается. При подключении внешних сервисов оператор обязан предварительно проверить применимые требования и при необходимости обновить настоящую Политику.</p>
<h2>7. Сроки обработки и уничтожение</h2>
<p>Данные заявки обрабатываются до достижения цели обращения, отзыва согласия или отпадения правового основания, но по общему правилу не более '.SG_CONSENT_RETENTION_DAYS.' календарных дней с даты последнего взаимодействия по заявке, если более длительное хранение не требуется для заключения/исполнения договора или исполнения требований законодательства. После достижения цели и при отсутствии иного законного основания данные подлежат удалению или уничтожению в установленном оператором порядке.</p>
<h2>8. Права субъекта и отзыв согласия</h2>
<p>Субъект вправе получать сведения об обработке своих персональных данных, требовать их уточнения, блокирования или уничтожения при наличии предусмотренных законом оснований, а также отозвать согласие. Запрос или отзыв можно направить на [sg_operator_email] либо по адресу оператора: [sg_operator_address]. В обращении следует указать сведения, позволяющие оператору идентифицировать заявителя и соответствующую заявку.</p>
<h2>9. Cookies и сторонняя аналитика</h2>
<p>В поставляемой версии Сайта не подключены рекламные системы и сторонние системы веб-аналитики. Функция выбора светлой/тёмной темы сохраняет настройку непосредственно в браузере пользователя. Если в дальнейшем будут подключены аналитические, рекламные или иные сторонние технологии, оператору необходимо до их запуска проверить основания обработки и при необходимости обновить Политику и механизм согласия.</p>
<h2>10. Меры защиты</h2>
<p>Оператор принимает необходимые правовые, организационные и технические меры для защиты персональных данных, включая разграничение доступа, использование защищённого соединения HTTPS на рабочем Сайте, своевременное обновление программного обеспечения, резервное копирование в необходимом объёме, контроль доступа к административной части и почтовому ящику, а также применение иных мер исходя из актуальных угроз. Конкретный состав внутренних мер определяется оператором с учётом используемой информационной системы.</p>
<h2>11. Актуализация Политики</h2>
<p>Актуальная редакция Политики постоянно доступна на этой странице. При изменении целей, состава данных, способов обработки, используемых сервисов или требований законодательства оператор актуализирует документ до начала соответствующей новой обработки.</p>';
}

function sg_consent_content() {
    return '<p><strong>Версия согласия:</strong> '.esc_html(SG_CONSENT_VERSION).'</p>
<p>Устанавливая отдельную отметку согласия под формой и отправляя заявку на Сайте [sg_site_host], я свободно, своей волей и в своём интересе даю <strong>[sg_operator_name]</strong>, адрес: [sg_operator_address], email: [sg_operator_email], [sg_operator_requisites], согласие на обработку моих персональных данных на следующих условиях.</p>
<h2>Цель обработки</h2>
<p>Приём и обработка моего обращения, связь со мной по заявке, уточнение параметров объекта и предоставление запрошенной мной информации об услугах.</p>
<h2>Перечень персональных данных</h2>
<p>Имя, номер телефона, текст сообщения и иные сведения, которые я добровольно укажу в поле сообщения.</p>
<h2>Перечень действий и способы обработки</h2>
<p>Сбор, запись, систематизация, накопление, хранение, уточнение (обновление, изменение), извлечение, использование, передача лицам, обрабатывающим данные по поручению оператора в объёме, необходимом для функционирования хостинга и электронной почты, блокирование, удаление и уничтожение. Обработка может осуществляться с использованием средств автоматизации и без их использования.</p>
<h2>Срок действия согласия</h2>
<p>Согласие действует до достижения цели обработки или его отзыва, но по общему правилу не более '.SG_CONSENT_RETENTION_DAYS.' календарных дней с даты последнего взаимодействия по заявке, если у оператора не возникло иное предусмотренное законом основание для дальнейшей обработки, в том числе в связи с заключением или исполнением договора.</p>
<h2>Отзыв согласия</h2>
<p>Согласие может быть отозвано путём направления обращения на [sg_operator_email] либо по адресу: [sg_operator_address]. После получения отзыва оператор прекращает обработку и уничтожает данные в сроки и случаях, предусмотренных законодательством, если отсутствует иное законное основание для продолжения обработки.</p>
<p>До отправки формы мне предоставлена возможность ознакомиться с <a href="'.esc_url(sg_privacy_url()).'">Политикой обработки персональных данных</a>. Я понимаю содержание настоящего согласия и подтверждаю его отдельной отметкой в форме.</p>';
}

add_shortcode('sg_privacy_policy', function(){
    return do_shortcode(sg_privacy_policy_content());
});
add_shortcode('sg_personal_data_consent', function(){
    return do_shortcode(sg_consent_content());
});

add_shortcode('sg_site_host', function(){ return esc_html(wp_parse_url(home_url('/'), PHP_URL_HOST)); });
add_shortcode('field_sg_operator_name', function(){ return esc_html(sg_legal_operator_name()); });
add_shortcode('sg_operator_address', function(){ return esc_html(sg_legal_address()); });
add_shortcode('sg_operator_email', function(){ return esc_html(antispambot(sg_legal_email())); });
add_shortcode('sg_operator_requisites', function(){
    $parts = array();
    if (sg_legal_inn()) $parts[] = 'ИНН '.sg_legal_inn();
    if (sg_legal_kpp()) $parts[] = 'КПП '.sg_legal_kpp();
    if (sg_legal_ogrn()) $parts[] = 'ОГРН/ОГРНИП '.sg_legal_ogrn();
    return esc_html(implode(', ', $parts));
});

function sg_legal_admin_notice() {
    if (!current_user_can('manage_options')) return;
    $front = (int) get_option('page_on_front');
    if (!$front) return;

    // Проверяем реальные сохранённые значения напрямую в postmeta. Это не зависит
    // от состояния инициализации ACF и не даёт ложного предупреждения после импорта.
    $name = trim((string) get_post_meta($front, 'operator_name', true));
    $inn  = trim((string) get_post_meta($front, 'operator_inn', true));
    $ogrn = trim((string) get_post_meta($front, 'operator_ogrn', true));

    // Для этой темы реквизиты уже известны и автоматически записываются в ACF.
    // Предупреждаем только если они действительно были удалены после инициализации.
    if (get_option('sg_existing_content_seeded') && (!$name || !$inn || !$ogrn)) {
        echo '<div class="notice notice-warning"><p><strong>Строй Гарант — персональные данные:</strong> в настройках главной удалены обязательные реквизиты оператора. Заполните юридическое наименование, ИНН и ОГРН — они используются в Политике и Согласии.</p></div>';
    }
}
add_action('admin_notices', 'sg_legal_admin_notice');
