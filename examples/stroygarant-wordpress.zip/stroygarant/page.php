<?php get_header();
$is_legal = (bool) get_post_meta(get_the_ID(), '_sg_legal_page', true);
?>
<header class="site-header legal-header">
  <div class="container nav-wrap">
    <a class="brand" href="<?php echo esc_url(home_url('/')); ?>">
      <img class="brand-logo" src="<?php echo esc_url(sg_asset('logo.jpg')); ?>" alt="Строй Гарант">
      <span>Строй Гарант</span>
    </a>
    <a class="legal-back" href="<?php echo esc_url(home_url('/')); ?>">← На главную</a>
  </div>
</header>
<main class="legal-page<?php echo $is_legal ? ' is-legal-document' : ''; ?>">
  <div class="container legal-container">
    <?php while(have_posts()): the_post(); ?>
      <?php if ($is_legal): ?><p class="section-kicker">Юридическая информация</p><?php endif; ?>
      <h1><?php the_title(); ?></h1>
      <div class="legal-meta">
        <?php if ($is_legal): ?>
          <span>ООО «СТРОЙ ГАРАНТ»</span>
          <span>ИНН <?php echo esc_html(sg_legal_inn()); ?></span>
          <span>ОГРН <?php echo esc_html(sg_legal_ogrn()); ?></span>
          <span>КПП <?php echo esc_html(sg_legal_kpp()); ?></span>
        <?php endif; ?>
      </div>
      <article class="legal-content"><?php the_content(); ?></article>
      <?php if ($is_legal): ?>
        <div class="legal-footer-note">
          <strong>Есть вопрос по персональным данным?</strong>
          <a href="mailto:<?php echo esc_attr(sg_legal_email()); ?>"><?php echo esc_html(antispambot(sg_legal_email())); ?></a>
        </div>
      <?php endif; ?>
    <?php endwhile; ?>
  </div>
</main>
<?php get_footer(); ?>
