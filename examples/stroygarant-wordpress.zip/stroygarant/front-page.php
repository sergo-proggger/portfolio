<?php
get_header();
$get = function($name, $fallback='') { return sg_get_field_safe($name, get_queried_object_id(), $fallback); };
$company = $get('company_name','Строй Гарант');
$hero_title = $get('hero_title','Ремонт и отделка коммерческих и жилых помещений под ключ в Москве');
$hero_text = $get('hero_text','Берём объект от черновых работ и инженерии до финишной отделки и сдачи. Один подрядчик на весь цикл работ.');
$cta = $get('cta_text','Рассчитать стоимость');
$logo_id = (int) $get('company_logo',0);
$hero_id = (int) $get('hero_image',0);
$hero_url = $hero_id ? wp_get_attachment_image_url($hero_id,'full') : sg_asset('projects/ketchup/14.01.05.jpg');
$about_title = $get('about_title','Один подрядчик — полный цикл работ');
$about_default = '<p><strong>Строй Гарант</strong> — строительная компания полного цикла для коммерческих и жилых объектов в Москве. Берём на себя строительные, отделочные и инженерные работы и отвечаем за результат одной командой.</p><p>Работаем с застройщиками, девелоперами, инвесторами, бизнесом и частными заказчиками. Соблюдаем согласованный график производства работ и применимые требования СНиП, ПУЭ и ГОСТ.</p>';
$about_text = $get('about_text',$about_default);
$services_title = $get('services_title','Всё необходимое для реализации объекта');
$projects_title = $get('projects_title','Объекты, которые говорят за нас');
$contacts_title = $get('contacts_title','Обсудим ваш объект и следующий шаг');
$phone = $get('phone','');
$email = $get('email','demo@example.invalid');
$address = $get('address','');
$form_title = $get('form_title','Получить предварительную оценку');
$form_text = $get('form_text','Оставьте контакты и коротко опишите объект. Свяжемся с вами, уточним задачу и предложим следующий шаг.');
$form_button = $get('form_button','Отправить заявку');
$status = isset($_GET['form_status']) ? sanitize_key(wp_unslash($_GET['form_status'])) : '';
$services = array();
$service_rows = sg_get_repeater_rows('services', get_queried_object_id(), array('title','text','image'));
foreach ($service_rows as $row) {
    $img = !empty($row['image']) ? (int) $row['image'] : 0;
    $services[] = array(
        'title' => $row['title'] ?? '',
        'text' => $row['text'] ?? '',
        'image' => $img ? wp_get_attachment_image_url($img, 'large') : '',
    );
}
if (!$services) $services = sg_default_services();

$projects = array();
$project_rows = sg_get_repeater_rows('projects', get_queried_object_id(), array('title','type','text','cover','gallery'));
foreach ($project_rows as $row) {
    $gallery_ids = $row['gallery'] ?? array();
    if (!is_array($gallery_ids)) $gallery_ids = array_filter(array_map('intval', (array) maybe_unserialize($gallery_ids)));
    $gallery = array();
    foreach ($gallery_ids as $id) {
        $u = wp_get_attachment_image_url((int) $id, 'full');
        if ($u) $gallery[] = $u;
    }
    $cover_id = !empty($row['cover']) ? (int) $row['cover'] : 0;
    $cover = $cover_id ? wp_get_attachment_image_url($cover_id, 'large') : ($gallery[0] ?? '');
    $projects[] = array(
        'title' => $row['title'] ?? '',
        'type' => $row['type'] ?? '',
        'text' => $row['text'] ?? '',
        'cover' => $cover,
        'gallery' => $gallery,
    );
}
if (!$projects) $projects = sg_default_projects();
?>
<header class="site-header" id="top"><div class="scroll-progress" aria-hidden="true"><span></span></div><div class="container nav-wrap">
<a class="brand" href="#top" aria-label="Строй Гарант"><?php if($logo_id) echo wp_get_attachment_image($logo_id,'medium',false,array('class'=>'brand-logo')); else echo '<img class="brand-logo" src="'.esc_url(sg_asset('logo.jpg')).'" alt="Логотип Строй Гарант">'; ?><span><?php echo esc_html($company); ?></span></a>
<div class="nav-actions"><button class="theme-toggle" type="button" aria-label="Переключить тему" title="Переключить светлую/тёмную тему"><span class="theme-icon theme-icon-sun" aria-hidden="true">☀</span><span class="theme-icon theme-icon-moon" aria-hidden="true">☾</span></button><button class="menu-toggle" type="button" aria-expanded="false" aria-controls="site-nav">Меню</button></div>
<nav class="site-nav" id="site-nav"><a href="#about">О компании</a><a href="#services">Услуги</a><a href="#projects">Проекты</a><a href="#process">Как работаем</a><a class="nav-cta" href="#contacts">Обсудить объект</a></nav>
</div></header>
<main>
<section class="hero" style="--hero:url('<?php echo esc_url($hero_url); ?>')"><div class="hero-shade"></div><div class="container hero-inner">
<div class="hero-copy"><p class="eyebrow">Строительная компания полного цикла · Москва</p><div class="hero-signature" aria-hidden="true"><span>СТРОЙ</span><span>ГАРАНТ</span></div><h1><?php echo esc_html($hero_title); ?></h1><p><?php echo esc_html($hero_text); ?></p><div class="hero-actions"><a class="btn btn-primary" href="#contacts"><?php echo esc_html($cta); ?> <span>↗</span></a><a class="btn btn-ghost" href="#projects">Посмотреть объекты</a></div></div>
<div class="hero-proof"><div><strong>Жилые и коммерческие объекты</strong></div><div><strong>Один подрядчик на весь цикл</strong></div><div><strong>Москва и Московская область</strong></div></div>
</div></section>
<section class="trust-strip"><div class="container trust-grid"><div><b>Под ключ</b><span>От инженерии до финишной сдачи</span></div><div><b>Один подрядчик</b><span>Строительные, отделочные и инженерные работы</span></div><div><b>По нормативам</b><span>СНиП · ПУЭ · ГОСТ</span></div><div><b>Для бизнеса и частных клиентов</b><span>Коммерческие и жилые помещения</span></div></div></section>
<section class="section about-section" id="about"><div class="container about-grid"><div class="about-visual"><img src="<?php echo esc_url(sg_asset('projects/bar-body-bel/13.42.15.jpg')); ?>" alt="Реализованный объект Строй Гарант" loading="lazy"><div class="about-caption">Реальный объект · Bar Body Studio</div></div><div class="about-copy"><div class="section-kicker">О компании</div><p class="about-lead">Строим не просто помещения — создаём готовую среду для жизни и бизнеса.</p><h2><?php echo esc_html($about_title); ?></h2><div class="rich-text"><?php echo wp_kses_post($about_text); ?></div><div class="advantages"><span>Комплексное строительство</span><span>Внутренняя отделка</span><span>Инженерные коммуникации</span><span>Ремонт под ключ</span></div><div class="standards"><strong>Работаем в профессиональном контуре</strong><p>Соблюдение применимых требований СНиП, ПУЭ и ГОСТ · согласованный график производства работ · единая ответственность за результат.</p></div></div></div></section>

<section class="section services-section" id="services"><div class="container"><div class="section-kicker">Услуги</div><div class="section-head split"><h2><?php echo esc_html($services_title); ?></h2><p>Не нужно координировать несколько бригад. Собираем работы в единый процесс и ведём объект до готового результата.</p></div><div class="service-grid">
<?php foreach($services as $i=>$s): ?><article class="service-card"><div class="service-media"<?php if(!empty($s['image'])): ?> style="background-image:url('<?php echo esc_url($s['image']); ?>')"<?php endif; ?>></div><div class="service-body"><h3><?php echo esc_html($s['title']); ?></h3><p><?php echo esc_html($s['text']); ?></p></div></article><?php endforeach; ?>
</div></div></section>
<section class="section projects-section" id="projects"><div class="container"><div class="portfolio-mark" aria-hidden="true">SELECTED WORKS</div><div class="section-kicker light-kicker">Портфолио</div><div class="section-head split light"><h2><?php echo esc_html($projects_title); ?></h2><p>Показываем реальные работы — без стоковых визуализаций. Нажмите на любой проект, чтобы открыть всю галерею.</p></div><div class="project-list">
<?php foreach($projects as $i=>$p): $cover=$p['cover']?:($p['gallery'][0]??''); ?><article class="project-card <?php echo $i%2?'project-reverse':''; ?>"><button class="project-open" type="button" data-project="<?php echo esc_attr($i); ?>" aria-label="Открыть галерею <?php echo esc_attr($p['title']); ?>"><div class="project-cover" style="--project-image:url('<?php echo esc_url($cover); ?>')"><img class="project-cover-image" src="<?php echo esc_url($cover); ?>" alt="<?php echo esc_attr($p['title']); ?>" loading="lazy"><span class="photo-count"><?php echo count($p['gallery']); ?> фото</span><span class="project-arrow">↗</span></div><div class="project-info"><span><?php echo esc_html($p['type']); ?></span><h3><?php echo esc_html($p['title']); ?></h3><p><?php echo esc_html($p['text']); ?></p><b>Открыть проект</b></div></button><script type="application/json" class="project-data"><?php echo wp_json_encode(array_values($p['gallery']),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE); ?></script></article><?php endforeach; ?>
</div></div></section>
<section class="section process-section" id="process"><div class="container"><div class="section-kicker">Как мы работаем</div><div class="section-head split"><h2>Понятный путь от заявки до готового объекта</h2><p>До старта фиксируем объём задачи и организацию работ. На каждом этапе заказчик понимает, что происходит дальше.</p></div><div class="process-grid">
<?php $steps=array(array('Заявка и консультация','Уточняем тип объекта, задачи и исходные данные.'),array('Выезд и замер','Осматриваем объект и собираем данные для оценки.'),array('Смета и план работ','Формируем состав работ, этапность и организацию проекта.'),array('Договор','Фиксируем согласованные условия до выхода на объект.'),array('Выполнение работ','Координируем строительные, отделочные и инженерные этапы.'),array('Сдача объекта','Проверяем результат и передаём готовый объект заказчику.')); foreach($steps as $i=>$step): ?><article><h3><?php echo esc_html($step[0]); ?></h3><p><?php echo esc_html($step[1]); ?></p></article><?php endforeach; ?>
</div></div></section>
<section class="cta-band"><div class="cta-watermark" aria-hidden="true">SG</div><div class="container"><p>Есть объект или проект?</p><h2>Давайте обсудим задачу и определим следующий шаг.</h2><a class="btn btn-light" href="#contacts">Получить консультацию <span>↗</span></a></div></section>
<section class="section contacts-section" id="contacts"><div class="container contacts-grid"><div><div class="section-kicker">Контакты</div><h2><?php echo esc_html($contacts_title); ?></h2><p class="contacts-intro">Расскажите, что нужно сделать. Для предварительного разговора достаточно типа объекта, площади и перечня основных работ.</p><div class="contact-list"><?php if($phone): ?><a href="tel:<?php echo esc_attr(sg_phone_href($phone)); ?>"><span>Телефон</span><strong><?php echo esc_html($phone); ?></strong></a><?php endif; ?><a href="mailto:<?php echo esc_attr(antispambot($email)); ?>"><span>Email</span><strong><?php echo esc_html(antispambot($email)); ?></strong></a><div><span>Адрес</span><strong><?php echo nl2br(esc_html($address)); ?></strong></div></div></div>
<div class="form-card"><span class="form-no">Заявка</span><h3><?php echo esc_html($form_title); ?></h3><p><?php echo esc_html($form_text); ?></p><?php if($status==='success'): ?><div class="form-msg success">Спасибо! Заявка отправлена.</div><?php elseif($status==='error'): ?><div class="form-msg error">Не удалось отправить заявку. Проверьте поля или напишите нам на email.</div><?php endif; ?><form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post"><input type="hidden" name="action" value="sg_submit_lead"><input type="hidden" name="consent_version" value="<?php echo esc_attr(SG_CONSENT_VERSION); ?>"><?php wp_nonce_field('sg_submit_lead','sg_nonce'); ?><input class="hp" type="text" name="website" tabindex="-1" autocomplete="off"><label>Ваше имя<input type="text" name="name" required maxlength="100" autocomplete="name" placeholder="Как к вам обращаться"></label><label>Телефон<input type="tel" name="phone" required maxlength="50" autocomplete="tel" placeholder="+7 ___ ___-__-__"></label><label>Объект и задача<textarea name="message" rows="5" maxlength="1500" placeholder="Например: офис 250 м², требуется ремонт под ключ"></textarea></label><label class="consent-check"><input type="checkbox" name="privacy_consent" value="1" required><span>Я даю отдельное <a href="<?php echo esc_url(sg_consent_url()); ?>" target="_blank" rel="noopener">согласие на обработку персональных данных</a> для обработки моей заявки и подтверждаю, что ознакомлен(а) с <a href="<?php echo esc_url(sg_privacy_url()); ?>" target="_blank" rel="noopener">Политикой обработки персональных данных</a>.</span></label><button class="btn btn-primary" type="submit"><?php echo esc_html($form_button); ?> <span>↗</span></button><small>Данные используются для обработки заявки и обратной связи по ней. Рекламные рассылки без отдельного согласия не выполняются.</small></form></div></div></section>
</main>
<footer class="site-footer"><div class="container footer-top"><div class="brand footer-brand"><img src="<?php echo esc_url(sg_asset('logo.jpg')); ?>" alt="Строй Гарант"><span><?php echo esc_html($company); ?></span></div><p>Строительство · отделка · инженерные работы<br>Москва и Московская область</p><a href="#top">Наверх ↑</a></div><div class="container footer-bottom"><span>© <?php echo esc_html(wp_date('Y')); ?> Строй Гарант</span><span><?php echo esc_html(antispambot($email)); ?></span><span class="footer-legal"><a href="<?php echo esc_url(sg_privacy_url()); ?>">Политика конфиденциальности</a><a href="<?php echo esc_url(sg_consent_url()); ?>">Согласие на обработку ПД</a></span></div></footer>
<button class="back-to-top" type="button" aria-label="Наверх" title="Наверх"><span>↑</span></button>
<div class="gallery-modal" aria-hidden="true"><button class="gallery-close" type="button" aria-label="Закрыть">×</button><button class="gallery-prev" type="button" aria-label="Предыдущее фото">‹</button><img src="" alt="Фото проекта"><button class="gallery-next" type="button" aria-label="Следующее фото">›</button><div class="gallery-counter"></div></div>
<?php get_footer(); ?>
