<?php get_header();
$name = nad_field('model_name');
$cover = nad_field('cover');
$contacts = nad_contacts();
$trips = nad_upcoming_trips(nad_field('travel_dates', []));
$about = nad_field('about');
$runway = nad_field('runway_highlights');
$stats = [
    'Height' => nad_field('height') === '' ? '—' : nad_field('height'),
    'Bust'   => nad_field('bust', '—'),
    'Waist'  => nad_field('waist', '—'),
    'Hips'   => nad_field('hips', '—'),
    'Shoes'  => nad_field('shoes', '—') . ' EU',
    'Hair'   => nad_field('hair', '—'),
    'Eyes'   => nad_field('eyes', '—'),
];
?>
<main id="main">
  <section class="hero" aria-labelledby="model-name">
    <div class="hero-photo"><?php echo nad_image($cover, 'full', ['loading'=>'eager', 'fetchpriority'=>'high', 'sizes'=>'(max-width: 700px) 100vw, 56vw']); ?></div>
    <div class="hero-copy">
      <h1 id="model-name"><?php echo esc_html($name); ?></h1>
      <dl class="hero-stats">
      <?php foreach ($stats as $label => $value): ?>
        <div class="<?php echo $value === '—' ? 'pending' : ''; ?>"><dt><?php echo esc_html($label); ?></dt><dd><?php echo esc_html($value); ?></dd></div>
      <?php endforeach; ?>
      </dl>
      <p class="hero-actions">
        <a class="text-link" href="#portfolio">View portfolio</a>
        <a class="text-link" href="#booking">Booking</a>
      </p>
    </div>
  </section>
  <?php if ($about || $runway): ?>
  <section class="about-section" id="about" aria-labelledby="title-about">
    <div class="about-heading"><span class="section-kicker">Behind the images</span><h2 id="title-about">About</h2></div>
    <div class="about-story">
      <?php if ($about): ?><div class="about-text"><?php echo wpautop(esc_html($about)); ?></div><?php endif; ?>
      <?php if ($runway): ?>
      <div class="runway-highlights"><h3>Selected runway</h3><ul>
        <?php foreach (preg_split('/\R\s*\R/', trim($runway)) as $show): ?>
        <li><?php echo esc_html($show); ?></li>
        <?php endforeach; ?>
      </ul></div>
      <?php endif; ?>
    </div>
  </section>
  <?php endif; ?>
  <?php nad_gallery('portfolio', 'Portfolio', 'scatter'); ?>
  <?php nad_gallery('snaps', 'Snaps', 'snaps'); ?>
  <?php nad_gallery('tests', 'Tests', 'scatter'); ?>
  <?php $videos = array_filter((array) nad_field('videos', []), fn($row) => !empty($row['video_file']) && wp_get_attachment_url($row['video_file'])); ?>
  <?php if ($videos): ?>
  <section class="video-section" id="video" aria-labelledby="title-video">
    <div class="section-head"><h2 id="title-video">Video</h2></div>
    <div class="video-grid">
    <?php foreach ($videos as $row): $video = wp_get_attachment_url($row['video_file']); $poster = wp_get_attachment_image_url($row['video_poster'], 'full'); ?>
      <figure><video controls playsinline preload="none" width="720" height="1280" <?php if ($poster): ?>poster="<?php echo esc_url($poster); ?>"<?php endif; ?> aria-label="<?php echo esc_attr($row['video_title'] ?: 'Model video'); ?>"><source src="<?php echo esc_url($video); ?>" type="video/mp4"></video><?php if ($row['video_title']): ?><figcaption><?php echo esc_html($row['video_title']); ?></figcaption><?php endif; ?></figure>
    <?php endforeach; ?>
    </div>
  </section>
  <?php endif; ?>
  <section class="measurements-section" id="measurements" aria-labelledby="title-measurements">
    <div class="comp-photo"><?php echo nad_image(nad_field('comp_photo') ?: $cover, 'nadezhda-gallery', ['sizes'=>'(max-width: 700px) 100vw, 40vw']); ?></div>
    <div class="comp-copy">
      <h2 id="title-measurements">Measurements</h2>
      <dl class="measurements">
      <?php foreach (['height'=>'Height','bust'=>'Bust','waist'=>'Waist','hips'=>'Hips'] as $key=>$label): $m = nad_measure($key); ?>
        <div class="<?php echo nad_field($key) === '' ? 'pending' : ''; ?>"><dt><?php echo esc_html($label); ?></dt><dd><?php echo esc_html($m[0]); ?><span><?php echo esc_html($m[1]); ?></span></dd></div>
      <?php endforeach; ?>
        <div><dt>Shoes</dt><dd><?php echo esc_html(nad_field('shoes', '—')); ?> EU</dd></div>
        <div><dt>Hair</dt><dd><?php echo esc_html(nad_field('hair', '—')); ?></dd></div>
        <div><dt>Eyes</dt><dd><?php echo esc_html(nad_field('eyes', '—')); ?></dd></div>
      </dl>
    </div>
  </section>
  <section class="booking-section" id="booking" aria-labelledby="title-booking">
    <div class="booking-intro">
      <h2 id="title-booking">Booking</h2>
      <?php if (nad_field('base_city')): ?><p class="booking-base">I’m based in <?php echo esc_html(nad_field('base_city')); ?></p><?php endif; ?>
      <?php if ($trips): ?>
      <div class="travel-schedule"><h3>Travel dates</h3><ul>
        <?php foreach ($trips as $trip): ?>
        <li><span class="travel-city"><?php echo esc_html($trip['city']); ?></span><span class="travel-range"><time datetime="<?php echo esc_attr($trip['start']); ?>"><?php echo esc_html(nad_travel_label($trip['start'])); ?></time><span aria-hidden="true"> / </span><span class="screen-reader-text"> to </span><time datetime="<?php echo esc_attr($trip['end']); ?>"><?php echo esc_html(nad_travel_label($trip['end'])); ?></time></span></li>
        <?php endforeach; ?>
      </ul></div>
      <?php endif; ?>
    </div>
    <div class="booking-content">
      <?php if (nad_field('booking_note')): ?><p class="booking-note"><?php echo esc_html(nad_field('booking_note')); ?></p><?php endif; ?>
      <?php if ($contacts): ?>
      <ul class="booking-links">
      <?php foreach ($contacts as [$label, $text, $href, $external]): ?>
        <li><a href="<?php echo esc_url($href); ?>"<?php if ($external): ?> target="_blank" rel="noopener noreferrer"<?php endif; ?>><span class="contact-label"><?php echo esc_html($label); ?></span><span class="contact-value"><?php echo esc_html($text); ?></span></a></li>
      <?php endforeach; ?>
      </ul>
      <?php endif; ?>
      <?php if (nad_field('agency')): ?><p class="agency">My agency: <?php if (nad_field('agency_url')): ?><a href="<?php echo esc_url(nad_field('agency_url')); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html(nad_field('agency')); ?></a><?php else: echo esc_html(nad_field('agency')); endif; ?></p><?php endif; ?>
    </div>
  </section>
</main>
<?php get_footer(); ?>
