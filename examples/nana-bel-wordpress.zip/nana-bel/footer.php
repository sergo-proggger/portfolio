<footer class="site-footer"><span>© <?php echo esc_html(date('Y') . ' ' . nad_field('model_name')); ?></span><a href="#main">Back to top ↑</a></footer>
<dialog class="lightbox" aria-label="Photo viewer">
  <button class="lightbox-close" aria-label="Close photo viewer">×</button>
  <button class="lightbox-prev" aria-label="Previous photograph">←</button>
  <figure><img width="1600" height="1600" alt=""><figcaption aria-live="polite"></figcaption></figure>
  <button class="lightbox-next" aria-label="Next photograph">→</button>
</dialog>
<?php wp_footer(); ?></body></html>
