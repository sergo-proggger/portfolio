<!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1">
<?php if (is_front_page()): ?>
<script>
// Start before first paint; the deadline also works if the main bundle fails.
(() => {
  const root = document.documentElement;
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const started = performance.now();
  let done = false;
  root.classList.add('intro-loading');
  const finish = (immediate = false) => {
    if (done) return;
    done = true;
    clearTimeout(deadline);
    root.classList.remove('intro-loading');
    if (!immediate && !reduced) {
      root.classList.add('intro-revealing');
      setTimeout(() => root.classList.remove('intro-revealing'), 800);
    }
  };
  const deadline = setTimeout(() => finish(), 3000);
  window.nadIntro = {
    ready: () => setTimeout(() => finish(), Math.max(0, (reduced ? 0 : 700) - (performance.now() - started)))
  };
  window.addEventListener('pageshow', event => { if (event.persisted) finish(true); });
  document.addEventListener('keydown', () => finish(true), {once:true});
  document.addEventListener('pointerdown', () => finish(true), {once:true, passive:true});
})();
</script>
<?php endif; ?>
<?php wp_head(); ?></head>
<body <?php body_class(); ?>><?php wp_body_open(); ?>
<?php if (is_front_page()): ?>
<div class="site-preloader" aria-hidden="true" hidden>
  <div class="preloader-signature">
    <span class="preloader-name"><?php echo esc_html(nad_field('model_name')); ?></span>
    <span class="preloader-line"></span>
  </div>
</div>
<?php endif; ?>
<a class="skip-link" href="#main">Skip to content</a>
<header class="site-header">
  <a class="wordmark" href="<?php echo esc_url(home_url('/')); ?>"><?php echo esc_html(nad_field('model_name')); ?></a>
  <nav aria-label="Main navigation">
  <?php foreach (['about'=>'About','portfolio'=>'Portfolio','snaps'=>'Snaps','tests'=>'Tests','video'=>'Video','booking'=>'Booking'] as $id=>$label): ?>
    <?php if ($id === 'about' && !nad_field('about') && !nad_field('runway_highlights')) { continue; } ?>
    <a href="<?php echo esc_url(home_url('/#' . $id)); ?>"><?php echo esc_html($label); ?></a>
  <?php endforeach; ?>
  </nav>
</header>
