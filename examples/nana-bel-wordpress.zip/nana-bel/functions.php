<?php
if (!defined('ABSPATH')) { exit; }
add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['style', 'script', 'gallery', 'caption']);
    add_image_size('nadezhda-gallery', 1000, 1500, false);
    remove_theme_support('widgets-block-editor');
});
add_action('wp_enqueue_scripts', function () {
    $dir = get_template_directory();
    wp_enqueue_style('nadezhda', get_template_directory_uri() . '/assets/site.css', [], filemtime($dir . '/assets/site.css'));
    wp_enqueue_script('nadezhda', get_template_directory_uri() . '/assets/site.js', [], filemtime($dir . '/assets/site.js'), ['strategy' => 'defer', 'in_footer' => true]);
});
add_filter('acf/settings/save_json', fn() => get_stylesheet_directory() . '/acf-json');
add_filter('acf/settings/load_json', function ($paths) { $paths[] = get_stylesheet_directory() . '/acf-json'; return array_unique($paths); });
add_action('admin_notices', function () {
    if (!function_exists('get_field') && current_user_can('activate_plugins')) {
        echo '<div class="notice notice-error"><p>Тема Nadezhda: активируй ACF Pro для редактирования главной.</p></div>';
    }
});
function nad_field($key, $fallback = '') {
    $value = function_exists('get_field') ? get_field($key, (int) get_option('page_on_front')) : null;
    return ($value === null || $value === false || $value === '') ? $fallback : $value;
}
function nad_image($id, $size = 'nadezhda-gallery', $attributes = []) {
    if (!$id) { return ''; }
    $attributes = array_merge(['loading' => 'lazy', 'decoding' => 'async'], $attributes);
    return wp_get_attachment_image((int) $id, $size, false, $attributes);
}
function nad_measure($key) {
    $value = nad_field($key);
    if ($value === '' || !is_numeric($value)) { return ['— cm', '— in']; }
    $cm = (float) $value;
    return [rtrim(rtrim(number_format($cm, 1, '.', ''), '0'), '.') . ' cm', number_format($cm / 2.54, 1, '.', '') . ' in'];
}
function nad_gallery($key, $label, $class = '') {
    $ids = nad_field($key, []);
    if (!$ids) { return; }
    $count = count($ids);
    ?>
    <section class="gallery-section <?php echo esc_attr($class); ?>" id="<?php echo esc_attr($key); ?>" aria-labelledby="title-<?php echo esc_attr($key); ?>">
      <div class="section-head"><h2 id="title-<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></h2><span class="section-count"><?php echo esc_html($count . ($count === 1 ? ' photograph' : ' photographs')); ?></span></div>
      <div class="photo-grid" data-gallery="<?php echo esc_attr($key); ?>">
      <?php foreach ($ids as $n => $id): $url = wp_get_attachment_image_url($id, 'full'); if (!$url) { continue; }
        $src = wp_get_attachment_image_src($id, 'nadezhda-gallery'); $ratio = ($src && $src[2]) ? round($src[1] / $src[2], 4) : 0.6667; ?>
        <a class="photo-link reveal<?php echo $ratio > 1.1 ? ' is-wide' : ''; ?>" href="<?php echo esc_url($url); ?>" style="--r:<?php echo esc_attr($ratio); ?>" aria-label="<?php echo esc_attr($label . ' — photograph ' . ($n + 1)); ?>">
          <?php echo nad_image($id, 'nadezhda-gallery', ['sizes' => '(max-width: 700px) 50vw, 33vw']); ?>
        </a>
      <?php endforeach; ?>
      </div>
    </section>
    <?php
}
// Contacts that are filled in the admin; empty ones are not shown to visitors.
function nad_contacts() {
    $list = [];
    $email = nad_field('email'); $phone = nad_field('phone');
    if ($email) { $list[] = ['Email', $email, 'mailto:' . $email, false]; }
    if ($phone) { $list[] = ['Phone', $phone, 'tel:' . preg_replace('/[^+0-9]/', '', $phone), false]; }
    foreach (['instagram' => 'Instagram', 'telegram' => 'Telegram', 'tiktok' => 'TikTok'] as $key => $label) {
        $url = nad_field($key);
        if ($url) { $list[] = [$label, nad_handle($url), $url, true]; }
    }
    return $list;
}
function nad_handle($url) {
    $path = trim((string) wp_parse_url($url, PHP_URL_PATH), '/');
    $host = preg_replace('/^www\./', '', (string) wp_parse_url($url, PHP_URL_HOST));
    if ($path && preg_match('/(instagram\.com|t\.me|telegram\.me|tiktok\.com)$/', $host)) { return '@' . ltrim(strtok($path, '/'), '@'); }
    return $host ?: $url;
}
// The public portfolio is English; the WordPress dashboard keeps its Russian locale.
add_filter('language_attributes', function ($output) { return is_admin() ? $output : 'lang="en"'; });
add_filter('jpeg_quality', fn() => 80);
add_filter('wp_editor_set_quality', fn() => 80);
add_action('admin_menu', function () {
    add_menu_page('Редактировать портфолио', 'Портфолио', 'edit_pages', 'nad-portfolio', function () {
        $id = (int) get_option('page_on_front');
        echo '<div class="wrap"><h1>Портфолио Надежды</h1><p>Фотографии, видео, параметры и контакты находятся на странице «Главная».</p><a class="button button-primary" href="' . esc_url(get_edit_post_link($id)) . '">Редактировать главную</a></div>';
    }, 'dashicons-format-gallery', 3);
});
// Keep the front page editor focused on ACF, without an empty block canvas.
add_filter('use_block_editor_for_post', function ($use, $post) {
    return (int) $post->ID === (int) get_option('page_on_front') ? false : $use;
}, 10, 2);
add_filter('big_image_size_threshold', fn() => 1600);

// Expired trips disappear after their final day in the WordPress timezone.
function nad_upcoming_trips($rows, $today = null) {
    $today = $today ?: current_datetime()->format('Y-m-d');
    $trips = [];
    foreach ((array) $rows as $row) {
        $city = trim((string) ($row['travel_city'] ?? ''));
        $start = (string) ($row['travel_start'] ?? '');
        $end = (string) ($row['travel_end'] ?? '');
        $valid = true;
        foreach ([$start, $end] as $date) {
            $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $date, wp_timezone());
            if (!$parsed || $parsed->format('Y-m-d') !== $date) { $valid = false; }
        }
        if (!$city || !$valid || $end < $start || $end < $today) { continue; }
        $trips[] = ['city' => $city, 'start' => $start, 'end' => $end];
    }
    usort($trips, fn($a, $b) => strcmp($a['start'], $b['start']));
    return $trips;
}
function nad_travel_label($date) {
    return (new DateTimeImmutable($date, wp_timezone()))->format('j M Y');
}
