<!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class(); ?>><?php wp_body_open(); ?>
<a class="skip-link" href="#main">Перейти к содержанию</a>
<header class="site-header"><div class="container header-inner">
<a class="brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php echo esc_attr(cn_get('brand')); ?> — главная"><span class="brand-mark" aria-hidden="true"><svg viewBox="0 0 48 48" fill="none"><path d="M6 13h25l11 8-8 12L6 26zM14 29v9h17M25 38v-7" stroke="currentColor" stroke-width="2"/><circle cx="32" cy="23" r="5" stroke="currentColor" stroke-width="2"/></svg></span><span><?php cn_text('brand'); ?><small>Видеонаблюдение и системы безопасности</small></span></a>
<nav class="navigation" aria-label="Основная навигация"><a href="<?php echo esc_url(home_url('/') . '#solutions'); ?>">Объекты</a><a href="<?php echo esc_url(home_url('/') . '#services'); ?>">Услуги</a><a href="<?php echo esc_url(home_url('/') . '#process'); ?>">Преимущества</a><a href="<?php echo esc_url(home_url('/') . '#contacts'); ?>">Контакты</a></nav>
<?php if (cn_form_on()): ?><a class="header-phone" href="<?php echo esc_url(cn_phone_uri()); ?>"><?php cn_text('phone'); ?></a><?php endif; ?>
<a class="header-call" href="<?php echo esc_url(cn_phone_uri()); ?>" aria-label="Позвонить: <?php echo esc_attr(cn_get('phone')); ?>"><svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M6.6 3.5 9.4 3l1.5 4.3-1.9 1.4a12 12 0 0 0 6.3 6.3l1.4-1.9 4.3 1.5-.5 2.8c-.2 1-1.1 1.6-2.1 1.5C10.9 18.3 5.7 13.1 5.1 5.6c-.1-1 .5-1.9 1.5-2.1Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg></a>
<?php if (cn_form_on()): ?><button class="header-callback" data-callback>Обратный звонок</button><?php else: ?><a class="header-callback" href="<?php echo esc_url(cn_phone_uri()); ?>"><?php cn_text('phone'); ?></a><?php endif; ?>
<button class="menu-toggle" aria-expanded="false" aria-controls="mobile-menu" aria-label="Открыть меню"><span></span><span></span></button>
</div><nav id="mobile-menu" class="mobile-menu" aria-label="Навигация на телефоне" hidden><a href="<?php echo esc_url(home_url('/') . '#solutions'); ?>">Объекты</a><a href="<?php echo esc_url(home_url('/') . '#services'); ?>">Услуги</a><a href="<?php echo esc_url(home_url('/') . '#process'); ?>">Преимущества</a><a href="<?php echo esc_url(home_url('/') . '#contacts'); ?>">Контакты</a></nav></header>
