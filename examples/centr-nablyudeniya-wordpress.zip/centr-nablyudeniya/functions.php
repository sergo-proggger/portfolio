<?php
if (!defined('ABSPATH')) { exit; }
function cn_defaults() {
    return [
        'brand' => 'Центр наблюдения',
        'brand_image' => 0,
        'services_heading' => 'Услуги',
        'services_intro' => 'Вам не придется ни о чем беспокоиться. Мы берем на себя все этапы работы:',
        'solutions_heading' => 'Решения для любых задач',
        'why_heading' => 'Почему выбирают нас?',
        'contact_heading' => 'Обсудить монтаж',
        'hero_title' => 'Ищете надежный способ защитить свой дом, офис или бизнес?',
        'hero_text' => 'Мы предлагаем полный комплекс услуг по проектированию, подбору оборудования и монтажу систем видеонаблюдения любой сложности.',
        'area' => 'Краснодар и весь Краснодарский край',
        'phone' => '',
        'email' => '',
        'address' => '',
        'legal_name' => '',
        'inn' => '',
        'ogrnip' => '',
        'contact_text' => '',
        'service_1_title' => 'Выезд специалиста и аудит',
        'service_1_text' => 'Бесплатно приедем на объект, найдем «слепые зоны» и подберем оптимальные места для камер.',
        'service_2_title' => 'Индивидуальный проект',
        'service_2_text' => 'Составим смету под ваш бюджет и задачи без переплат за лишнее оборудование.',
        'service_3_title' => 'Монтаж и настройка подключения',
        'service_3_text' => 'Произведем монтаж, подключим удаленный доступ на ваш смартфон или планшет.',
        'service_4_title' => 'Обучение',
        'service_4_text' => 'Покажем, как пользоваться системой, просматривать архив и управлять камерами.',
        'solution_1_title' => 'Для дома и дачи',
        'solution_1_text' => 'Контроль придомовой территории, безопасность близких и сохранность имущества во время вашего отсутствия.',
        'solution_2_title' => 'Для квартиры',
        'solution_2_text' => 'Компактные внутренние камеры с датчиками движения и аудиосвязью для присмотра за детьми или домашними животными.',
        'solution_3_title' => 'Для бизнеса и офисов',
        'solution_3_text' => 'Контроль работы сотрудников, кассовых зон, учет рабочего времени и защита от краж.',
        'solution_4_title' => 'Для складов и производства',
        'solution_4_text' => 'Масштабные системы с распознаванием номеров, ночной съемкой высокой четкости и интеграцией со СКУД.',
        'step_1_title' => 'Гарантия до 12 месяцев',
        'step_1_text' => 'На оборудование и все виды монтажных работ.',
        'step_2_title' => 'Удаленный доступ 24/7',
        'step_2_text' => 'Смотрите прямую трансляцию и архив из любой точки мира через удобное мобильное приложение.',
        'step_3_title' => 'Честная цена',
        'step_3_text' => 'Смета утверждается до начала работ и не меняется в процессе.',
        'step_4_title' => 'Опыт и профессионализм',
        'step_4_text' => 'Используем только проверенное оборудование от ведущих мировых брендов (Hikvision, Dahua, HiWatch и др.).',
        'show_projects' => false,
        'callback_ready' => false,
        'consent_text' => '',
        'policy_text' => '',
    ];
}
function cn_get($key) {
    $defaults = cn_defaults();
    if (function_exists('get_field')) {
        $page_id = (int) get_option('page_on_front');
        if ($page_id && metadata_exists('post', $page_id, 'cn_' . $key)) {
            $value = get_field('cn_' . $key, $page_id, false);
            return is_bool($defaults[$key] ?? null) ? (bool) $value : $value;
        }
    }
    return get_theme_mod('cn_' . $key, $defaults[$key] ?? '');
}
function cn_text($key) { echo esc_html(cn_get($key)); }
// Without the form the site collects no personal data: every call-to-action leads to the phone or e-mail.
function cn_form_on() { return (bool) cn_get('callback_ready'); }
function cn_mail_uri() { return 'mailto:' . cn_get('email'); }
function cn_phone_uri() { return 'tel:' . preg_replace('/[^+0-9]/', '', cn_get('phone')); }
add_action('after_setup_theme', function () { add_theme_support('title-tag'); add_theme_support('post-thumbnails'); add_theme_support('custom-logo'); add_theme_support('html5', ['style', 'script', 'gallery', 'caption']); });
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('cn-main', get_template_directory_uri() . '/assets/main.css', [], filemtime(get_template_directory() . '/assets/main.css'));
    wp_enqueue_script('cn-main', get_template_directory_uri() . '/assets/main.js', [], filemtime(get_template_directory() . '/assets/main.js'), true);
});
add_action('init', function () {
    register_post_type('cn_project', ['labels' => ['name' => 'Выполненные работы', 'singular_name' => 'Работа', 'add_new_item' => 'Добавить работу', 'edit_item' => 'Редактировать работу'], 'public' => false, 'show_ui' => true, 'show_in_rest' => true, 'supports' => ['title', 'editor', 'thumbnail'], 'menu_icon' => 'dashicons-camera']);
});
require_once get_template_directory() . '/inc/acf-fields.php';

// Телефон принимается только после проверки формы и передаётся через почту WordPress.
add_action('wp_ajax_cn_callback', 'cn_callback');
add_action('wp_ajax_nopriv_cn_callback', 'cn_callback');
function cn_callback() {
    if (!cn_get('callback_ready')) { wp_send_json_error(['message' => 'Приём заявок пока не открыт. Свяжитесь с нами по телефону.'], 503); }
    if (!check_ajax_referer('cn_callback', 'nonce', false)) {
        wp_send_json_error(['message' => 'Обновите страницу и попробуйте ещё раз.'], 403);
    }
    if (!empty($_POST['website'])) { wp_send_json_error(['message' => 'Не удалось отправить заявку.'], 400); }
    $phone = isset($_POST['phone']) && is_string($_POST['phone']) ? wp_unslash($_POST['phone']) : '';
    $digits = preg_replace('/\D/', '', $phone);
    if (strlen($phone) > 30 || !preg_match('/^[+0-9() .-]+$/', $phone) || strlen($digits) < 10 || strlen($digits) > 15) {
        wp_send_json_error(['message' => 'Проверьте номер телефона.'], 400);
    }
    if (!isset($_POST['consent']) || $_POST['consent'] !== '1') {
        wp_send_json_error(['message' => 'Подтвердите согласие на обработку телефона.'], 400);
    }
    $accepted_hash = isset($_POST['consent_hash']) && is_string($_POST['consent_hash']) ? $_POST['consent_hash'] : '';
    if (!hash_equals(hash('sha256', cn_get('consent_text')), $accepted_hash)) { wp_send_json_error(['message' => 'Текст согласия обновлён. Обновите страницу и прочитайте его перед отправкой.'], 409); }
    $ip = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '';
    $key = 'cn_callback_' . hash_hmac('sha256', $ip, wp_salt('nonce'));
    if (get_transient($key)) { wp_send_json_error(['message' => 'Заявка уже отправлена. Повторить можно через минуту.'], 429); }
    $recipient = sanitize_email(cn_get('email'));
    if (!is_email($recipient)) { wp_send_json_error(['message' => 'Приём заявок временно недоступен. Позвоните нам.'], 503); }
    set_transient($key, 1, MINUTE_IN_SECONDS);
    $consent_text = cn_get('consent_text');
    $receipt = "Телефон: " . $phone . "\nДата UTC: " . gmdate('c') . "\nID заявки: " . wp_generate_uuid4() . "\nСогласие: отдельная отметка, подтверждено при отправке\nSHA-256 согласия: " . hash('sha256', $consent_text) . "\n\nТекст принятого согласия:\n" . $consent_text;
    $record = wp_insert_post(['post_type' => 'cn_request', 'post_status' => 'private', 'post_title' => 'Обратный звонок ' . gmdate('Y-m-d H:i:s'), 'post_content' => $receipt], true);
    if (is_wp_error($record) || !$record) { delete_transient($key); wp_send_json_error(['message' => 'Не удалось сохранить заявку. Попробуйте позже.'], 503); }
    $sent = wp_mail($recipient, 'Заявка на обратный звонок — Центр наблюдения', $receipt, ['Content-Type: text/plain; charset=UTF-8']);
    update_post_meta($record, 'cn_mail_accepted', $sent ? 'yes' : 'no');
    if (!$sent) {
        delete_transient($key);
        wp_send_json_error(['message' => 'Не удалось отправить номер. Попробуйте позже или позвоните нам.'], 503);
    }
    wp_send_json_success(['message' => 'Мы вам перезвоним']);
}

function cn_document_url($type) { return add_query_arg('cn_document', $type, home_url('/')); }
add_action('template_redirect', function () {
    $type = isset($_GET['cn_document']) && is_string($_GET['cn_document']) ? $_GET['cn_document'] : '';
    if (in_array($type, ['consent','policy'], true)) { status_header(200); nocache_headers(); require get_template_directory() . '/document.php'; exit; }
});
add_action('init', function () {
    register_post_type('cn_request', ['labels' => ['name' => 'Заявки и согласия', 'singular_name' => 'Заявка'], 'public' => false, 'show_ui' => true, 'show_in_rest' => false, 'supports' => ['title','editor'], 'capabilities' => array_fill_keys(['edit_post','read_post','delete_post','edit_posts','edit_others_posts','publish_posts','read_private_posts','delete_posts','delete_private_posts','delete_published_posts','delete_others_posts','edit_private_posts','edit_published_posts'], 'manage_options'), 'menu_icon' => 'dashicons-shield']);
});
