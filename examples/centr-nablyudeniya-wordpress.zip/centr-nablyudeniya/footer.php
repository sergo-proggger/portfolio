<footer class="site-footer"><div class="container footer-inner"><div><strong><?php cn_text('brand'); ?></strong><p>Видеонаблюдение и системы безопасности</p></div><div class="legal"><p><?php cn_text('legal_name'); ?></p><p>ИНН <?php cn_text('inn'); ?> · ОГРНИП <?php cn_text('ogrnip'); ?></p></div><?php if (cn_form_on()): ?><a class="footer-policy" href="<?php echo esc_url(cn_document_url('policy')); ?>">Политика обработки данных</a><?php endif; ?><a href="#main" class="back-top">Наверх ↑</a></div></footer>
<a class="floating-top" href="#main" aria-label="Вернуться наверх" hidden>↑</a>
<div class="mobile-actions" aria-label="Быстрая связь"><a class="mobile-actions-call" href="<?php echo esc_url(cn_phone_uri()); ?>"><svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M6.6 3.5 9.4 3l1.5 4.3-1.9 1.4a12 12 0 0 0 6.3 6.3l1.4-1.9 4.3 1.5-.5 2.8c-.2 1-1.1 1.6-2.1 1.5C10.9 18.3 5.7 13.1 5.1 5.6c-.1-1 .5-1.9 1.5-2.1Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>Позвонить</a><?php if (cn_form_on()): ?><button type="button" class="mobile-actions-callback" data-callback>Перезвоните мне</button><?php else: ?><a class="mobile-actions-callback" href="<?php echo esc_url(cn_mail_uri()); ?>"><svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3.5" y="5.5" width="17" height="13" stroke="currentColor" stroke-width="1.6"/><path d="m4 6.5 8 6 8-6" stroke="currentColor" stroke-width="1.6"/></svg>Написать</a><?php endif; ?></div>
<?php if (cn_form_on()): ?>
<dialog id="callback-dialog" aria-labelledby="callback-title">
<button class="dialog-close" type="button" aria-label="Закрыть">×</button>
<div class="callback-entry"><h2 id="callback-title">Оставьте номер телефона</h2>
<form id="callback-form" action="<?php echo esc_url(admin_url('admin-ajax.php')); ?>" method="post">
<input type="hidden" name="action" value="cn_callback"><input type="hidden" name="consent_hash" value="<?php echo esc_attr(hash('sha256', cn_get('consent_text'))); ?>"><input type="hidden" name="nonce" value="<?php echo esc_attr(wp_create_nonce('cn_callback')); ?>">
<label class="phone-label" for="callback-phone">Ваш телефон</label>
<input id="callback-phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="+7 (___) ___-__-__" required autofocus maxlength="30" aria-describedby="callback-error">
<div class="form-trap" aria-hidden="true"><label>Сайт<input name="website" type="text" tabindex="-1" autocomplete="off"></label></div>
<label class="consent"><input type="checkbox" name="consent" value="1" required><span>Даю <a href="<?php echo esc_url(cn_document_url('consent')); ?>" target="_blank" rel="noopener">согласие на обработку персональных данных</a> для обратного звонка.</span></label>
<p class="policy-link"><a href="<?php echo esc_url(cn_document_url('policy')); ?>" target="_blank" rel="noopener">Политика обработки персональных данных</a></p>
<p id="callback-error" class="form-error" role="alert"></p>
<button type="submit" class="button primary">Жду звонка <span aria-hidden="true">↗</span></button>
</form></div>
<div class="callback-success" hidden role="status" aria-live="polite"><span class="success-mark" aria-hidden="true"><svg viewBox="0 0 48 48" fill="none"><circle cx="24" cy="24" r="21" stroke="currentColor"/><path d="m14 24 7 7 13-14" stroke="currentColor" stroke-width="2"/></svg></span><h2>Мы вам перезвоним</h2><p>Ваш номер отправлен. Спасибо за обращение!</p><button class="button success-close" type="button">Хорошо</button></div>
</dialog>
<?php endif; ?>
<?php wp_footer(); ?></body></html>
