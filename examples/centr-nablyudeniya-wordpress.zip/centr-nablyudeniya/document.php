<?php get_header(); ?>
<main id="main" class="legal-document"><div class="container"><a class="legal-back" href="<?php echo esc_url(home_url('/')); ?>">← На главную</a>
<?php $text = cn_get($type === 'consent' ? 'consent_text' : 'policy_text'); $paragraphs = preg_split('/\r?\n/', $text); foreach ($paragraphs as $i => $paragraph) { if (!$i) { echo '<h1>' . esc_html($paragraph) . '</h1>'; } else { echo '<p>' . esc_html($paragraph) . '</p>'; } } ?>
</div></main><?php get_footer(); ?>
