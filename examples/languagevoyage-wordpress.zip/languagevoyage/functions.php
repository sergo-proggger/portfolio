<?php
if (!defined('ABSPATH')) exit;
require_once get_template_directory() . '/inc/acf-fields.php';

function eml_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('style','script','gallery','caption'));
    register_nav_menus(array('primary' => 'Главное меню'));
}
add_action('after_setup_theme', 'eml_setup');

function eml_assets() {
    $v = wp_get_theme()->get('Version');
    wp_enqueue_style('eml-fonts', 'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Fraunces:opsz,wght@9..144,500;9..144,600&display=swap', array(), null);
    wp_enqueue_style('eml-main', get_template_directory_uri() . '/assets/css/main.css', array('eml-fonts'), $v);
    wp_enqueue_script('eml-main', get_template_directory_uri() . '/assets/js/main.js', array(), $v, true);
    wp_localize_script('eml-main', 'emlContact', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('eml_contact_form'),
    ));
}
add_action('wp_enqueue_scripts', 'eml_assets');

function eml_contact_action_link($contact) {
    $contact = trim($contact);
    if ($contact === '') return null;

    if (is_email($contact)) {
        return array('href' => 'mailto:' . $contact, 'label' => 'Написать на почту');
    }

    if (preg_match('/^@[A-Za-z0-9_]{4,32}$/', $contact)) {
        return array('href' => 'https://t.me/' . ltrim($contact, '@'), 'label' => 'Написать в Telegram');
    }

    $digits = preg_replace('/[^0-9]/', '', $contact);
    if (strlen($digits) >= 10 && preg_match('/^[+0-9][0-9\s\-()]{8,}$/', $contact)) {
        if (strlen($digits) === 11 && $digits[0] === '8') {
            $digits = '7' . substr($digits, 1);
        } elseif (strlen($digits) === 10) {
            $digits = '7' . $digits;
        }
        return array('href' => 'tel:+' . $digits, 'label' => 'Позвонить');
    }

    return null;
}

function eml_contact_email_html($name, $contact, $service, $message) {
    $rows = array(
        array('Имя', $name),
        array('Как связаться', $contact),
        array('Направление', $service !== '' ? $service : '—'),
    );

    $rows_html = '';
    foreach ($rows as $row) {
        list($label, $value) = $row;
        $rows_html .= '<div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid #eef2ee">'
            . '<div style="font-family:Arial,Helvetica,sans-serif;font-size:11px;text-transform:uppercase;letter-spacing:.08em;font-weight:700;color:#7a9084;margin:0 0 6px">' . esc_html($label) . '</div>'
            . '<div style="font-family:Arial,Helvetica,sans-serif;font-size:16px;font-weight:700;color:#24483a;margin:0">' . esc_html($value) . '</div>'
            . '</div>';
    }

    if ($message !== '') {
        $rows_html .= '<div style="margin-top:4px;padding:18px 20px;background:#f0f8f3;border-left:3px solid #c93f52;border-radius:0 14px 14px 0">'
            . '<div style="font-family:Arial,Helvetica,sans-serif;font-size:11px;text-transform:uppercase;letter-spacing:.08em;font-weight:700;color:#7a9084;margin:0 0 8px">Сообщение</div>'
            . '<div style="font-family:Georgia,\'Times New Roman\',serif;font-style:italic;font-size:15px;line-height:1.6;color:#24483a;margin:0">«' . nl2br(esc_html($message)) . '»</div>'
            . '</div>';
    }

    $action = eml_contact_action_link($contact);
    $button_html = '';
    if ($action) {
        $button_html = '<div style="margin-top:26px">'
            . '<a href="' . esc_url($action['href']) . '" style="display:inline-block;padding:13px 26px;background:linear-gradient(135deg,#2f6f55,#4a8869);color:#ffffff;text-decoration:none;font-family:Arial,Helvetica,sans-serif;font-weight:700;font-size:14px;border-radius:999px">' . esc_html($action['label']) . ' →</a>'
            . '</div>';
    }

    $date = esc_html(wp_date('d.m.Y, H:i'));

    $html = '<!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Новая заявка</title></head>'
        . '<body style="margin:0;padding:0;background:#eef3ee">'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#eef3ee;padding:32px 16px"><tr><td align="center">'
        . '<table role="presentation" width="560" cellpadding="0" cellspacing="0" style="width:560px;max-width:100%;background:#ffffff;border-radius:24px;overflow:hidden;box-shadow:0 20px 50px rgba(36,72,58,.12)">'
        . '<tr><td style="background:linear-gradient(135deg,#2f6f55,#4a8869);padding:26px 32px">'
        . '<table role="presentation" cellpadding="0" cellspacing="0"><tr>'
        . '<td style="width:42px;height:42px;border-radius:13px;background:linear-gradient(145deg,#e8f4ec,#fff0e8);text-align:center;vertical-align:middle"><span style="font-family:Georgia,\'Times New Roman\',serif;font-weight:700;font-size:17px;color:#2f6f55">LV</span></td>'
        . '<td style="padding-left:14px;vertical-align:middle">'
        . '<div style="font-family:Arial,Helvetica,sans-serif;color:#ffffff;font-size:17px;font-weight:700">Language Voyage</div>'
        . '<div style="font-family:Arial,Helvetica,sans-serif;color:rgba(255,255,255,.82);font-size:11px;text-transform:uppercase;letter-spacing:.1em;margin-top:3px">Новая заявка с сайта</div>'
        . '</td></tr></table>'
        . '</td></tr>'
        . '<tr><td style="padding:32px">' . $rows_html . $button_html . '</td></tr>'
        . '<tr><td style="padding:18px 32px;border-top:1px solid #eef2ee;background:#fbfdfb">'
        . '<div style="font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#8a9990">Заявка с формы на <a href="https://languagevoyage.ru" style="color:#2f6f55;text-decoration:none;font-weight:700">languagevoyage.ru</a> · ' . $date . '</div>'
        . '</td></tr>'
        . '</table></td></tr></table>'
        . '</body></html>';

    return $html;
}

function eml_handle_contact_form() {
    check_ajax_referer('eml_contact_form', 'nonce');

    // Форма выключена в админке: сайт не принимает персональные данные.
    if (!eml_get('show_form', false)) {
        wp_send_json_error(array('message' => 'Приём заявок через сайт отключён. Напишите, пожалуйста, в Telegram или на почту.'), 403);
    }

    // Honeypot: настоящие посетители это поле не видят и не заполняют.
    if (!empty($_POST['website'])) {
        wp_send_json_success(array('message' => 'Спасибо! Заявка отправлена.'));
    }

    $name    = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
    $contact = isset($_POST['contact']) ? sanitize_text_field(wp_unslash($_POST['contact'])) : '';
    $service = isset($_POST['service']) ? sanitize_text_field(wp_unslash($_POST['service'])) : '';
    $message = isset($_POST['message']) ? sanitize_textarea_field(wp_unslash($_POST['message'])) : '';

    if ($name === '' || $contact === '') {
        wp_send_json_error(array('message' => 'Заполните, пожалуйста, имя и способ связи.'));
    }

    $to = eml_get('email', 'demo@example.invalid');

    $body = eml_contact_email_html($name, $contact, $service, $message);

    $subject = 'Новая заявка с сайта — ' . $name;
    $headers = array('Content-Type: text/html; charset=UTF-8');
    $site_host = wp_parse_url(home_url(), PHP_URL_HOST);
    $headers[] = 'From: Language Voyage <wordpress@' . $site_host . '>';
    if (is_email($contact)) {
        $headers[] = 'Reply-To: ' . $contact;
    }

    $sent = wp_mail($to, $subject, $body, $headers);

    if ($sent) {
        wp_send_json_success(array('message' => 'Спасибо! Заявка отправлена, я скоро свяжусь с вами.'));
    } else {
        wp_send_json_error(array('message' => 'Не получилось отправить заявку. Попробуйте, пожалуйста, ещё раз чуть позже или напишите напрямую в Telegram/WhatsApp.'));
    }
}
add_action('wp_ajax_eml_contact_submit', 'eml_handle_contact_form');
add_action('wp_ajax_nopriv_eml_contact_submit', 'eml_handle_contact_form');

add_action('wp_mail_failed', function ($wp_error) {
    error_log('EML contact form mail failed: ' . $wp_error->get_error_message());
});

function eml_get($key, $default='') {
    if (function_exists('get_field')) {
        $v = get_field($key);
        if ($v !== null && $v !== false && $v !== '') return $v;
    }
    return $default;
}

function eml_img($key, $fallback) {
    if (function_exists('get_field')) {
        $v = get_field($key);
        if (is_array($v) && !empty($v['url'])) return $v['url'];
        if (is_numeric($v)) { $u = wp_get_attachment_image_url((int)$v, 'full'); if ($u) return $u; }
        if (is_string($v) && $v) return $v;
    }
    return get_template_directory_uri() . '/assets/images/' . ltrim($fallback, '/');
}

function eml_has($key) {
    if (!function_exists('get_field')) return false;
    $v = get_field($key);
    if (is_array($v) && !empty($v['url'])) return true;
    if (is_numeric($v) && (int)$v > 0) return true;
    if (is_string($v) && $v !== '') return true;
    return false;
}

function eml_file($key, $fallback) {
    if (function_exists('get_field')) {
        $v = get_field($key);
        if (is_array($v) && !empty($v['url'])) return $v['url'];
        if (is_numeric($v)) { $u = wp_get_attachment_url((int)$v); if ($u) return $u; }
        if (is_string($v) && $v) return $v;
    }
    return get_template_directory_uri() . '/assets/video/' . ltrim($fallback, '/');
}
