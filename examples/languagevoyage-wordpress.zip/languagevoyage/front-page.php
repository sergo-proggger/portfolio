<?php get_header();
$hero = eml_img('hero_photo','lifestyle.jpg');
$teaching = eml_img('teaching_photo','about-lesson.jpg');
$group = eml_img('group_photo','corporate-team.jpg');
$lifestyle = eml_img('lifestyle_photo','lifestyle-travel.jpg');
$teacher_name = eml_get('teacher_name','Анастасия Адриенкоми');
$has_teacher_video = true; // теперь есть настоящий ролик с преподавателем — показываем его по умолчанию, ACF-поле можно переопределить
$teacher_video = eml_file('teacher_video','anastasia-classroom.mp4');
$teacher_video_poster = get_template_directory_uri() . '/assets/images/anastasia-video-poster.jpg';
$video_alt_photo = get_template_directory_uri() . '/assets/images/gallery-classroom.jpg';
$tg = eml_get('telegram_url',''); $wa = eml_get('whatsapp_url',''); $email = eml_get('email','');
?>
<a class="floating-contact" href="#contact" data-floating-contact aria-label="Написать мне">
  <span class="floating-contact-icon" aria-hidden="true">✉</span>
  <span class="floating-contact-text">Написать мне</span>
</a>

<section id="top" class="hero">
  <div class="hero-atmosphere" aria-hidden="true"><i class="orb orb-a"></i><i class="orb orb-b"></i><i class="orb orb-c"></i><span class="route route-a"></span><span class="route route-b"></span></div>
  <div class="hero-banner-full reveal">
    <img src="<?php echo esc_url($hero); ?>" alt="<?php echo esc_attr($teacher_name); ?> — педагог английского языка">
    <span class="hero-banner-note photo-note">English • Culture • Confidence</span>
    <div class="floating-card card-one"><strong>Real-world English</strong><small>для жизни и карьеры</small></div>
    <div class="floating-card card-two"><strong>UK • USA • Thailand</strong><small>международный опыт</small></div>
  </div>
  <div class="wrap hero-copy reveal">
    <div class="eyebrow"><strong><?php echo esc_html($teacher_name); ?></strong><span>Педагог английского языка • международный опыт</span></div>
    <h1><?php echo esc_html(eml_get('hero_title','Английский, который открывает двери')); ?></h1>
    <p class="hero-sub"><?php echo esc_html(eml_get('hero_text','В страны, компании и новые возможности. Обучение с ясной структурой, сильной коммуникативной базой и пониманием языка в реальной международной среде.')); ?></p>
    <div class="hero-actions"><a class="btn primary bright" href="#contact">Обсудить обучение <span>↗</span></a><a class="btn ghost" href="#services">Посмотреть форматы <span>↓</span></a></div>
    <div class="country-row"><span>United Kingdom</span><span>USA</span><span>Thailand</span></div>
  </div>
</section>

<div class="voyage-strip" aria-label="Направления обучения"><div class="voyage-track"><span>English for life</span><i>✦</i><span>Career communication</span><i>✦</i><span>Business English</span><i>✦</i><span>International confidence</span><i>✦</i><span>English for life</span><i>✦</i><span>Career communication</span><i>✦</i><span>Business English</span><i>✦</i><span>International confidence</span></div></div>

<section id="about" class="section about">
  <div class="wrap about-grid">
    <div class="section-kicker">Обо мне</div>
    <div class="about-copy reveal"><div class="person-name"><?php echo esc_html($teacher_name); ?></div><h2><?php echo esc_html(eml_get('about_title','Язык как инструмент для реальной жизни')); ?></h2><div class="richtext"><?php echo wp_kses_post(eml_get('about_text','<p>Педагог английского языка с международным опытом жизни и работы в Великобритании, США и Таиланде.</p><p>Мой профессиональный путь сформировал современный, зрелый подход к обучению: ясная структура, сильная коммуникативная база и глубокое понимание языка в реальной среде.</p><p>Я работаю с теми, кто ценит качество, системность и результат. Помогаю ученикам развивать уверенность, расширять горизонты и использовать английский как инструмент для жизни, карьеры и международного общения.</p><p>Если вам нужен преподаватель, который сочетает профессионализм, культуру и высокий стандарт работы — я буду рада сотрудничеству.</p>')); ?></div></div>
    <div class="about-visual reveal"><div class="image-frame"><img src="<?php echo esc_url($teaching); ?>" alt="Занятие английским языком"></div><span class="image-caption">Practice • confidence • communication</span></div>
  </div>
</section>

<section class="section principles">
  <div class="wrap">
    <div class="section-kicker">Подход</div>
    <div class="principles-grid">
      <article class="reveal"><span class="principle-icon">✦</span><h3>Системность</h3><p>Понятная логика обучения, последовательное развитие навыков и работа на конкретный результат.</p></article>
      <article class="reveal"><span class="principle-icon">◎</span><h3>Коммуникация</h3><p>Английский не ради упражнений, а для уверенного общения, работы, путешествий и международных задач.</p></article>
      <article class="reveal"><span class="principle-icon">↗</span><h3>Реальная среда</h3><p>Опыт жизни и работы в Великобритании, США и Таиланде помогает объяснять не только язык, но и культурный контекст.</p></article>
    </div>
  </div>
</section>


<section id="video" class="section video-story">
  <div class="wrap video-story-grid">
    <div class="video-story-copy reveal">
      <div class="section-kicker">В работе</div>
      <div class="person-name person-name-large"><?php echo esc_html($teacher_name); ?></div>
      <h2>Английский в живом общении, а не только в учебнике</h2>
      <p>Занятия строятся вокруг реальной коммуникации: говорить, слышать, объяснять свою мысль и чувствовать себя уверенно в международной среде.</p>
      <div class="video-points">
        <span>Разговорная практика</span>
        <span>Живые сценарии</span>
        <span>Уверенная коммуникация</span>
      </div>
    </div>
    <div class="video-shell reveal">
      <?php if ($has_teacher_video) : ?>
      <div class="video-frame">
        <video controls playsinline preload="metadata" poster="<?php echo esc_url($teacher_video_poster); ?>">
          <source src="<?php echo esc_url($teacher_video); ?>" type="video/mp4">
          Ваш браузер не поддерживает воспроизведение видео.
        </video>
        <span class="video-badge">Real lesson • Language Voyage</span>
      </div>
      <?php else : ?>
      <div class="video-frame video-frame-photo">
        <img src="<?php echo esc_url($video_alt_photo); ?>" alt="<?php echo esc_attr($teacher_name); ?> на занятии">
        <span class="video-badge">Real lesson • Language Voyage</span>
      </div>
      <?php endif; ?>
      <div class="video-caption"><strong>Фрагмент занятия</strong><span>живой формат преподавания и работа с учениками</span></div>
    </div>
  </div>
</section>


<section id="gallery" class="section lesson-gallery">
  <div class="wrap">
    <div class="gallery-heading reveal">
      <div>
        <div class="section-kicker">Как проходят занятия</div>
        <h2>Живая практика, проекты и общение</h2>
      </div>
      <p>Индивидуальная работа, групповые занятия и образовательные проекты — английский становится частью реальных ситуаций, а не только учебника.</p>
    </div>

    <div class="lesson-slider reveal" data-lesson-slider tabindex="0" aria-label="Фотографии занятий">
      <div class="lesson-slider-viewport">
        <div class="lesson-slider-track">
          <figure class="lesson-slide is-active">
            <div class="lesson-slide-media" style="--slide-bg:url('<?php echo esc_url(get_template_directory_uri() . '/assets/images/lesson-conversation.jpg'); ?>')">
              <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/lesson-conversation.jpg'); ?>" alt="Студенты во время занятия — живая практика в аудитории">
            </div>
            <figcaption><strong>Разговорная практика</strong><span>Работа с живыми сценариями и уверенностью в общении.</span></figcaption>
          </figure>
          <figure class="lesson-slide">
            <div class="lesson-slide-media" style="--slide-bg:url('<?php echo esc_url(get_template_directory_uri() . '/assets/images/gallery-classroom.jpg'); ?>')">
              <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/gallery-classroom.jpg'); ?>" alt="Анастасия во время работы в аудитории">
            </div>
            <figcaption><strong>Рабочая атмосфера</strong><span>Занятия в современной образовательной среде.</span></figcaption>
          </figure>
          <figure class="lesson-slide">
            <div class="lesson-slide-media" style="--slide-bg:url('<?php echo esc_url(get_template_directory_uri() . '/assets/images/gallery-hallway.jpg'); ?>')">
              <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/gallery-hallway.jpg'); ?>" alt="Анастасия с группой учеников">
            </div>
            <figcaption><strong>Групповой формат</strong><span>Коммуникация, вовлечение и практика в группе.</span></figcaption>
          </figure>
          <figure class="lesson-slide">
            <div class="lesson-slide-media" style="--slide-bg:url('<?php echo esc_url(get_template_directory_uri() . '/assets/images/group.jpg'); ?>')">
              <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/group.jpg'); ?>" alt="Анастасия с большой группой учеников">
            </div>
            <figcaption><strong>Образовательные проекты</strong><span>Работа с группами и коллаборации с образовательными организациями.</span></figcaption>
          </figure>
        </div>
      </div>
      <div class="lesson-slider-controls">
        <div class="lesson-slider-counter"><span data-slide-current>1</span><i>/</i><span data-slide-total>4</span></div>
        <div class="lesson-slider-dots" aria-label="Перейти к фотографии">
          <button class="is-active" type="button" aria-label="Фото 1" data-slide-dot="0"></button>
          <button type="button" aria-label="Фото 2" data-slide-dot="1"></button>
          <button type="button" aria-label="Фото 3" data-slide-dot="2"></button>
          <button type="button" aria-label="Фото 4" data-slide-dot="3"></button>
        </div>
        <div class="lesson-slider-arrows">
          <button type="button" aria-label="Предыдущее фото" data-slide-prev>←</button>
          <button type="button" aria-label="Следующее фото" data-slide-next>→</button>
        </div>
      </div>
    </div>
  </div>
</section>

<section id="services" class="section services">
  <div class="wrap"><div class="section-kicker">С чем я работаю</div><div class="section-head"><h2>Обучение и языковое сопровождение</h2><p>Форматы для частных клиентов, команд и организаций — с опорой на реальные задачи, а не только на учебник.</p></div>
    <div class="service-list">
      <article class="reveal service-photo-card"><div class="service-photo"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/service-individual.jpg'); ?>" alt="Индивидуальные занятия"></div><div class="service-body"><h3>Индивидуальные занятия очно и онлайн</h3><p>Персональная программа обучения, адаптированная под цели, уровень и темп ученика.</p><a class="btn primary bright small" href="#contact">Записаться <span>↗</span></a></div></article>
      <article class="reveal service-photo-card"><div class="service-photo"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/service-corporate.jpg'); ?>" alt="Корпоративный английский"></div><div class="service-body"><h3>Корпоративный английский</h3><p>Обучение команд, развитие профессиональной коммуникации и работа с реальными бизнес-ситуациями.</p><a class="btn primary bright small" href="#contact">Записаться <span>↗</span></a></div></article>
      <article class="reveal service-photo-card"><div class="service-photo"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/service-translation.jpg'); ?>" alt="Переводческие услуги"></div><div class="service-body"><h3>Переводческие услуги</h3><p>Сопровождение на переговорах и встречах, бизнес‑переписка и устные переводы.</p><a class="btn primary bright small" href="#contact">Записаться <span>↗</span></a></div></article>
      <article class="reveal service-photo-card"><div class="service-photo"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/service-format.jpg'); ?>" alt="Онлайн и очные занятия"></div><div class="service-body"><h3>Онлайн и очные занятия</h3><p>Гибкий формат обучения для частных клиентов и организаций.</p><a class="btn primary bright small" href="#contact">Записаться <span>↗</span></a></div></article>
    </div>
  </div>
</section>

<?php
$eml_directions = array(
  array('icon'=>'✦','title'=>'Развитие разговорной речи','text'=>'Уверенная коммуникация, работа с реальными ситуациями, живой современный язык.'),
  array('icon'=>'◎','title'=>'Постановка произношения','text'=>'Естественное звучание, интонация, ритм речи, основанные на международном опыте.'),
  array('icon'=>'↗','title'=>'Подготовка к экзаменам','text'=>'Структурированная подготовка к школьным, международным и вступительным экзаменам.'),
  array('icon'=>'⟡','title'=>'Английский для переезда','text'=>'Язык для адаптации за границей: бытовые ситуации, документы, коммуникация и интеграция.'),
  array('icon'=>'✺','title'=>'Бизнес-коммуникация','text'=>'Английский для деловой среды, международных проектов, переговоров и профессионального общения.'),
  array('icon'=>'▲','title'=>'Академический английский','text'=>'Чтение, письмо, анализ текстов и структурированное выражение мыслей.'),
  array('icon'=>'●','title'=>'Межкультурная коммуникация','text'=>'Навыки общения в международной среде, понимание культурных различий и уверенное взаимодействие.'),
  array('icon'=>'✿','title'=>'Английский для детей','text'=>'Развитие интереса, уверенности, коммуникативных навыков и естественного восприятия языка.'),
  array('icon'=>'★','title'=>'Английский для подростков','text'=>'Современный подход, мотивация, расширение кругозора и подготовка к реальным задачам.'),
  array('icon'=>'◆','title'=>'Английский для взрослых','text'=>'Практический язык для работы, путешествий, переезда и личного развития.'),
  array('icon'=>'➤','title'=>'Подготовка к собеседованиям','text'=>'Профессиональная речь, самопрезентация и уверенные ответы.'),
  array('icon'=>'⬡','title'=>'Сопровождение обучения','text'=>'Контроль прогресса, корректировка программы, регулярная поддержка и мотивация.'),
);
?>
<section id="directions" class="section directions">
  <div class="wrap">
    <div class="section-kicker">Направления</div>
    <div class="section-head directions-head"><h2>Английский под конкретную задачу</h2><p>От произношения и подготовки к экзаменам до переезда, бизнеса и межкультурной коммуникации — программа собирается под конкретную цель ученика.</p></div>
    <div class="directions-grid">
      <?php foreach ($eml_directions as $eml_d) : ?>
      <article class="direction-card reveal">
        <span class="direction-icon"><?php echo esc_html($eml_d['icon']); ?></span>
        <h3><?php echo esc_html($eml_d['title']); ?></h3>
        <div class="direction-more"><p><?php echo esc_html($eml_d['text']); ?></p></div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section id="corporate" class="section corporate">
  <div class="wrap corporate-grid">
    <div class="corporate-photo reveal"><div class="image-frame image-frame-wide"><img src="<?php echo esc_url($group); ?>" alt="Образовательная программа"></div><span class="soft-label">Education • teams • collaboration</span></div>
    <div class="corporate-copy reveal"><div class="section-kicker">Коллаборации</div><h2>Корпоративные и образовательные программы</h2><div class="programs"><div><h3>Коллаборации с компаниями</h3><p>Обучающие проекты, мастер‑классы, языковые программы и специальные форматы под задачи бизнеса.</p></div><div><h3>Сотрудничество с детскими садами</h3><p>Игровые занятия, раннее развитие речи и формирование естественного восприятия английского языка.</p></div><div><h3>Корпоративный английский</h3><p>Практика переговоров, презентаций, деловой переписки и профессиональной коммуникации.</p></div></div></div>
  </div>
</section>

<section id="formats" class="section formats">
  <div class="wrap"><div class="section-kicker">Больше, чем уроки</div><div class="formats-grid"><div class="formats-copy reveal"><h2>Обучение, перевод и межкультурная адаптация — в одном подходе</h2><p>Я объединяю обучение, переводческое сопровождение и межкультурную адаптацию. Такой формат помогает решать реальные международные задачи, а не просто учить язык.</p><div class="chips"><span>Для жизни</span><span>Для карьеры</span><span>Для бизнеса</span><span>Для переезда</span><span>Для международного общения</span></div></div><figure class="lifestyle reveal"><div class="image-frame"><img src="<?php echo esc_url($lifestyle); ?>" alt="Международный образ жизни"></div><figcaption>English beyond the classroom</figcaption></figure></div></div>
</section>

<section class="section quote"><div class="wrap"><blockquote>«Английский, который открывает двери — <em>в страны, компании, возможности.</em>»</blockquote></div></section>

<?php
$testimonials = array(
  array(
    'name' => eml_get('testimonial_1_name','Мария К.'),
    'role' => eml_get('testimonial_1_role','Индивидуальные занятия'),
    'text' => eml_get('testimonial_1_text','Работаю с Анастасией уже полгода: за это время речь стала гораздо увереннее, ушёл страх ошибиться. Занятия выстроены системно и по делу.'),
  ),
  array(
    'name' => eml_get('testimonial_2_name','Ирина П.'),
    'role' => eml_get('testimonial_2_role','Английский для детей'),
    'text' => eml_get('testimonial_2_text','Дочь начала заниматься с интересом, а не из-под палки. Видно, что Анастасия умеет находить подход и к детям, и к подросткам.'),
  ),
  array(
    'name' => eml_get('testimonial_3_name','Дмитрий С.'),
    'role' => eml_get('testimonial_3_role','Корпоративный английский'),
    'text' => eml_get('testimonial_3_text','Организовали для команды курс делового английского — стало проще вести переговоры с зарубежными партнёрами. Формат подобрали именно под наши задачи.'),
  ),
  array(
    'name' => eml_get('testimonial_4_name','Алексей В.'),
    'role' => eml_get('testimonial_4_role','Подготовка к переезду'),
    'text' => eml_get('testimonial_4_text','Готовился к переезду в Великобританию — Анастасия помогла не только с языком, но и с пониманием культурного контекста. Очень практично.'),
  ),
);
?>
<section id="reviews" class="section reviews">
  <div class="wrap">
    <div class="section-head">
      <div>
        <div class="section-kicker">Отзывы</div>
        <h2>Что говорят ученики и клиенты</h2>
      </div>
      <p class="reviews-note">Демо-отзывы — Анастасия добавит настоящие через личный кабинет.</p>
    </div>

    <div class="testimonial-slider reveal" data-testimonial-slider tabindex="0" aria-label="Отзывы учеников и клиентов">
      <div class="testimonial-slider-viewport">
        <div class="testimonial-slider-track">
          <?php foreach ($testimonials as $eml_ti => $eml_t) : ?>
          <figure class="testimonial-slide<?php echo $eml_ti === 0 ? ' is-active' : ''; ?>">
            <span class="testimonial-quote-mark" aria-hidden="true">&ldquo;</span>
            <blockquote><?php echo esc_html($eml_t['text']); ?></blockquote>
            <figcaption><strong><?php echo esc_html($eml_t['name']); ?></strong><span><?php echo esc_html($eml_t['role']); ?></span></figcaption>
          </figure>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="testimonial-slider-controls">
        <div class="testimonial-slider-counter"><span data-t-slide-current>1</span><i>/</i><span data-t-slide-total><?php echo count($testimonials); ?></span></div>
        <div class="testimonial-slider-dots" aria-label="Перейти к отзыву">
          <?php foreach ($testimonials as $eml_ti => $eml_t) : ?>
          <button<?php echo $eml_ti === 0 ? ' class="is-active"' : ''; ?> type="button" aria-label="Отзыв <?php echo esc_attr($eml_ti + 1); ?>" data-t-slide-dot="<?php echo esc_attr($eml_ti); ?>"></button>
          <?php endforeach; ?>
        </div>
        <div class="testimonial-slider-arrows">
          <button type="button" aria-label="Предыдущий отзыв" data-t-slide-prev>←</button>
          <button type="button" aria-label="Следующий отзыв" data-t-slide-next>→</button>
        </div>
      </div>
    </div>
  </div>
</section>


<section id="contact" class="section contact">
  <div class="wrap contact-card reveal">
    <div class="contact-orb" aria-hidden="true"></div>
    <div class="contact-copy">
      <div class="section-kicker">Контакт</div>
      <h2><?php echo esc_html(eml_get('cta_title','Давайте обсудим вашу задачу')); ?></h2>
      <p><?php echo esc_html(eml_get('cta_text','Подберу формат обучения, корпоративной программы или переводческого сопровождения под вашу цель.')); ?></p>
      <div class="contact-note">Можно кратко описать вашу цель — я предложу подходящий формат работы.</div>
    </div>
    <?php if (eml_get('show_form', false)) : ?>
    <form class="demo-contact-form" data-demo-form>
      <div class="form-row">
        <label>
          <span>Ваше имя</span>
          <input type="text" name="name" placeholder="Например, Мария" autocomplete="name" required>
        </label>
        <label>
          <span>Как связаться</span>
          <input type="text" name="contact" placeholder="Telegram, WhatsApp или телефон" required>
        </label>
      </div>
      <label>
        <span>Что вас интересует</span>
        <select name="service">
          <option value="">Выберите направление</option>
          <option>Индивидуальные занятия</option>
          <option>Корпоративный английский</option>
          <option>Переводческие услуги</option>
          <option>Подготовка к экзаменам / собеседованию</option>
          <option>Другое</option>
        </select>
      </label>
      <label>
        <span>Коротко о задаче</span>
        <textarea name="message" rows="4" placeholder="Напишите цель, удобный формат и любые важные детали"></textarea>
      </label>
      <label class="form-hp" aria-hidden="true">
        <span>Website</span>
        <input type="text" name="website" tabindex="-1" autocomplete="off">
      </label>
      <div class="form-bottom">
        <button type="submit" class="btn primary"><span class="btn-label">Отправить заявку <span>↗</span></span></button>
        <small>Отвечаю обычно в течение дня — в удобном вам формате связи.</small>
      </div>
      <div class="demo-form-success" role="status" aria-live="polite" hidden>Спасибо! Заявка отправлена, я скоро свяжусь с вами.</div>
      <div class="demo-form-error" role="alert" aria-live="assertive" hidden></div>
    </form>
    <?php else : $phone = eml_get('phone',''); ?>
    <div class="contact-links">
      <?php if ($tg) : ?><a class="contact-link" href="<?php echo esc_url($tg); ?>" target="_blank" rel="noopener"><span class="contact-link-label">Telegram</span><span class="contact-link-action">Написать ↗</span></a><?php endif; ?>
      <?php if ($wa) : ?><a class="contact-link" href="<?php echo esc_url($wa); ?>" target="_blank" rel="noopener"><span class="contact-link-label">WhatsApp</span><span class="contact-link-action">Написать ↗</span></a><?php endif; ?>
      <?php if ($email) : ?><a class="contact-link" href="<?php echo esc_url('mailto:' . $email); ?>"><span class="contact-link-label">Почта</span><span class="contact-link-action"><?php echo esc_html($email); ?></span></a><?php endif; ?>
      <?php if ($phone) : ?><a class="contact-link" href="<?php echo esc_url('tel:' . preg_replace('/[^+0-9]/', '', $phone)); ?>"><span class="contact-link-label">Телефон</span><span class="contact-link-action"><?php echo esc_html($phone); ?></span></a><?php endif; ?>
      <small class="contact-links-note">Отвечаю обычно в течение дня.</small>
    </div>
    <?php endif; ?>
  </div>
</section>
<?php get_footer(); ?>
