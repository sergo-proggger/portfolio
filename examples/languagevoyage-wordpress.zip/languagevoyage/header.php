<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div class="site-preloader" aria-hidden="true">
  <div class="preloader-inner">
    <div class="preloader-emblem"><span>LV</span><i></i><i></i><i></i></div>
    <div class="preloader-wordmark">Language Voyage</div>
    <div class="preloader-caption">English • communication • opportunities</div>
    <div class="preloader-line"><span></span></div>
  </div>
</div>
<div class="scroll-progress" aria-hidden="true"><span></span></div>

<header class="site-header">
  <div class="wrap header-inner">
    <a class="brand" href="<?php echo esc_url(home_url('/')); ?>">
      <span class="brand-mark">LV</span>
      <span class="brand-copy"><b>Language Voyage</b><small>English • Communication • International</small></span>
    </a>
    <button class="menu-btn" type="button" aria-expanded="false" aria-controls="main-nav"><span></span><span></span><span></span><b>Меню</b></button>
    <nav id="main-nav" class="main-nav">
      <a href="#about">Обо мне</a>
      <a href="#video">Видео</a>
      <a href="#services">Услуги</a>
      <a href="#corporate">Для компаний</a>
      <a href="#formats">Форматы</a>
      <a href="#reviews">Отзывы</a>
      <a class="nav-cta" href="#contact">Связаться <span>↗</span></a>
    </nav>
  </div>
</header>
<main>
