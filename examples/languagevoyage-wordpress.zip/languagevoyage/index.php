<?php get_header(); ?><section class="simple-page"><div class="wrap"><h1><?php bloginfo('name'); ?></h1><p>Перейдите на главную страницу сайта.</p></div></section><?php get_footer(); ?>
