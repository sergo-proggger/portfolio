<?php
if (!defined('ABSPATH')) exit;
add_action('acf/init', function(){
    if (!function_exists('acf_add_local_field_group')) return;
    acf_add_local_field_group(array(
        'key'=>'group_eml_home','title'=>'Содержимое главной страницы',
        'fields'=>array(
            array('key'=>'field_eml_teacher_name','label'=>'Имя преподавателя','name'=>'teacher_name','type'=>'text','default_value'=>'Анастасия Адриенкоми'),
            array('key'=>'field_eml_hero_eyebrow','label'=>'Надзаголовок','name'=>'hero_eyebrow','type'=>'text'),
            array('key'=>'field_eml_hero_title','label'=>'Главный заголовок','name'=>'hero_title','type'=>'text'),
            array('key'=>'field_eml_hero_text','label'=>'Текст первого экрана','name'=>'hero_text','type'=>'textarea','rows'=>5),
            array('key'=>'field_eml_hero_photo','label'=>'Фото первого экрана','name'=>'hero_photo','type'=>'image','return_format'=>'array'),
            array('key'=>'field_eml_about_title','label'=>'Заголовок Обо мне','name'=>'about_title','type'=>'text'),
            array('key'=>'field_eml_about_text','label'=>'Текст Обо мне','name'=>'about_text','type'=>'wysiwyg','tabs'=>'visual'),
            array('key'=>'field_eml_teaching_photo','label'=>'Фото с учениками','name'=>'teaching_photo','type'=>'image','return_format'=>'array'),
            array('key'=>'field_eml_group_photo','label'=>'Групповое фото','name'=>'group_photo','type'=>'image','return_format'=>'array'),
            array('key'=>'field_eml_lifestyle_photo','label'=>'Lifestyle фото','name'=>'lifestyle_photo','type'=>'image','return_format'=>'array'),
            array('key'=>'field_eml_teacher_video','label'=>'Видео с занятия','name'=>'teacher_video','type'=>'file','return_format'=>'array','mime_types'=>'mp4,mov,webm'),
            array('key'=>'field_eml_cta_title','label'=>'CTA заголовок','name'=>'cta_title','type'=>'text'),
            array('key'=>'field_eml_cta_text','label'=>'CTA текст','name'=>'cta_text','type'=>'textarea'),
            array('key'=>'field_eml_telegram','label'=>'Telegram','name'=>'telegram_url','type'=>'url','instructions'=>'Ссылка вида https://t.me/имя'),
            array('key'=>'field_eml_whatsapp','label'=>'WhatsApp','name'=>'whatsapp_url','type'=>'url','instructions'=>'Ссылка вида https://wa.me/ (номер без плюса и пробелов)'),
            array('key'=>'field_eml_email','label'=>'Email','name'=>'email','type'=>'email','instructions'=>'Показывается в блоке «Контакт» кнопкой «Написать на почту».','default_value'=>'demo@example.invalid'),
            array('key'=>'field_eml_phone','label'=>'Телефон','name'=>'phone','type'=>'text','instructions'=>'Необязательно, например . Пустое поле на сайте не показывается.'),
            array('key'=>'field_eml_show_form','label'=>'Показывать форму заявки','name'=>'show_form','type'=>'true_false','ui'=>1,'default_value'=>0,'instructions'=>'Выключено: вместо формы кнопки Telegram, WhatsApp, почта и телефон, сайт не собирает данные. Включать форму только вместе с политикой обработки данных и согласием.'),
            array('key'=>'field_eml_testimonial_1_name','label'=>'Отзыв 1 — Имя','name'=>'testimonial_1_name','type'=>'text','default_value'=>'Мария К.'),
            array('key'=>'field_eml_testimonial_1_role','label'=>'Отзыв 1 — Кто / о чём','name'=>'testimonial_1_role','type'=>'text','default_value'=>'Индивидуальные занятия'),
            array('key'=>'field_eml_testimonial_1_text','label'=>'Отзыв 1 — Текст','name'=>'testimonial_1_text','type'=>'textarea','rows'=>4,'default_value'=>'Работаю с Анастасией уже полгода: за это время речь стала гораздо увереннее, ушёл страх ошибиться. Занятия выстроены системно и по делу.'),
            array('key'=>'field_eml_testimonial_2_name','label'=>'Отзыв 2 — Имя','name'=>'testimonial_2_name','type'=>'text','default_value'=>'Ирина П.'),
            array('key'=>'field_eml_testimonial_2_role','label'=>'Отзыв 2 — Кто / о чём','name'=>'testimonial_2_role','type'=>'text','default_value'=>'Английский для детей'),
            array('key'=>'field_eml_testimonial_2_text','label'=>'Отзыв 2 — Текст','name'=>'testimonial_2_text','type'=>'textarea','rows'=>4,'default_value'=>'Дочь начала заниматься с интересом, а не из-под палки. Видно, что Анастасия умеет находить подход и к детям, и к подросткам.'),
            array('key'=>'field_eml_testimonial_3_name','label'=>'Отзыв 3 — Имя','name'=>'testimonial_3_name','type'=>'text','default_value'=>'Дмитрий С.'),
            array('key'=>'field_eml_testimonial_3_role','label'=>'Отзыв 3 — Кто / о чём','name'=>'testimonial_3_role','type'=>'text','default_value'=>'Корпоративный английский'),
            array('key'=>'field_eml_testimonial_3_text','label'=>'Отзыв 3 — Текст','name'=>'testimonial_3_text','type'=>'textarea','rows'=>4,'default_value'=>'Организовали для команды курс делового английского — стало проще вести переговоры с зарубежными партнёрами. Формат подобрали именно под наши задачи.'),
            array('key'=>'field_eml_testimonial_4_name','label'=>'Отзыв 4 — Имя','name'=>'testimonial_4_name','type'=>'text','default_value'=>'Алексей В.'),
            array('key'=>'field_eml_testimonial_4_role','label'=>'Отзыв 4 — Кто / о чём','name'=>'testimonial_4_role','type'=>'text','default_value'=>'Подготовка к переезду'),
            array('key'=>'field_eml_testimonial_4_text','label'=>'Отзыв 4 — Текст','name'=>'testimonial_4_text','type'=>'textarea','rows'=>4,'default_value'=>'Готовился к переезду в Великобританию — Анастасия помогла не только с языком, но и с пониманием культурного контекста. Очень практично.'),
        ),
        'location'=>array(array(array('param'=>'page_type','operator'=>'==','value'=>'front_page'))),
        'position'=>'normal','style'=>'default'
    ));
});
